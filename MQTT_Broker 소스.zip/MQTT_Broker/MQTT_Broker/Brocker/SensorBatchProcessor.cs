﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Threading.Channels;
using MQTTnet;
using MQTTnet.Client;
using Google.Protobuf.Protocol;
using System.Diagnostics;


namespace MQTT_Broker
{

    public class SensorBatchProcessor // c# 채널 라이브러리
    {
        private readonly Channel<SensorMessage> _channel;
        private readonly int _batchSize;
        private readonly TimeSpan _flushInterval;
        private CancellationTokenSource? _cts;

        public SensorBatchProcessor(
               int maxCapacity = 30000,int batchSize = 1000,int flushSeconds = 1000)
        {
            _batchSize = batchSize;
            _flushInterval = TimeSpan.FromMilliseconds(flushSeconds);

            var options = new BoundedChannelOptions(maxCapacity)
            {
                FullMode = BoundedChannelFullMode.DropOldest,
                SingleReader = true,SingleWriter = false
            };
            _channel = Channel.CreateBounded<SensorMessage>(options);
        }

        // DropOldest 모드에서는 버퍼가 차도 즉시 이전 값을 버리고 기록하므로 대기 없이 항상 성공
        public void Enqueue(SensorMessage message)
        {
            _channel.Writer.TryWrite(message);
        }

        public void Start()
        {
            _cts = new CancellationTokenSource();
            _ = Task.Run(() => ProcessBatchLoopAsync(_cts.Token));
        }

        public void Stop()
        {
            _channel.Writer.Complete();
            _cts?.Cancel();
        }

        private async Task ProcessBatchLoopAsync(CancellationToken ct)
        {
            var batch = new List<SensorMessage>(_batchSize);
            var reader = _channel.Reader;

            while (!ct.IsCancellationRequested)
            {
                try
                {
                    if (!await reader.WaitToReadAsync(ct))
                        break;

                    int MesSizeCounter = 4;
                    var timeoutCts = new CancellationTokenSource(_flushInterval);
                    var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(ct, timeoutCts.Token);

                    while (batch.Count < _batchSize)
                    {
                        if (reader.TryRead(out var MSG))
                        {
                            batch.Add(MSG);
                            if (Interlocked.Add(ref MesSizeCounter, MSG.Length) > 50000)
                                break;
                        }
                        else
                        {
                            try
                            {
                                MSG = await reader.ReadAsync(linkedCts.Token);
                                batch.Add(MSG);
                                if (Interlocked.Add(ref MesSizeCounter, MSG.Length) > 50000)
                                    break;
                            }
                            catch (OperationCanceledException) when (timeoutCts.IsCancellationRequested)
                            {
                                break; // 1000개가 안 찼어도 주기 도달 시 플러시
                            }
                        }
                    }

                    if (batch.Count > 0)
                    {
                        SensorsMsg BSSensorsData = new SensorsMsg();
                        foreach (var item in batch)
                        {
                            //SensorMessage
                            SensorMsg SM = new SensorMsg();
                            SM.SensorID = item.ID;
                            SM.Msg = item.Payload;
                            BSSensorsData.Info.Add(SM);
                        }

                        BackEndSession.Default.Send(BSSensorsData);
                        batch.Clear();
                    }
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[BatchProcessor 예러! - 메시지 모으기 실패] {ex.Message}");
                }
            }
        }
    }
}