﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace MQTT_Broker
{
    public class SensorMessage
    {
        public SensorMessage(int id,string topic, string payload)
        {
            ID = id;
            Topic = topic;
            Payload = payload;
        }

        public int ID { get; set; }
        public int Length { get { return (Topic?.Length ?? 0) + (Payload?.Length ?? 0) + 4; } }
        public string Topic { get; set; }
        public string Payload { get; set; }
    }

    public class RealSensor
    { 
        public int ID { get; set; }
        public string Topic { get; set; }
        public int Type { get; set; }
    }

    public enum SensorType
    {
        Temperature = 0,
        Conveyor = 1,
        Camera = 2,
        FireSensors = 3,

        FireCamera = 5,
    }

    public class VirtualSensor
    {
        public int ID { get; set; }
        public string Topic { get; set; }
        public int Type { get; set; }
        public Vector3 pos { get; set; }
        public Vector3 rot { get; set; }
    }

    public static class ConvertUtil
    {
        public static int ToInt(string value)
        {
            return int.TryParse(value, out int result)
                ? result : int.MaxValue;
        }

        public static float ToFloat(string value)
        {
            return float.TryParse(value, NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out float result)
                ? result : float.MaxValue;
        }
    }
}
