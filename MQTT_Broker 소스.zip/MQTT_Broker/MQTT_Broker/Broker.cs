﻿using MQTTnet.Server;
using MQTTnet;
using System.Threading.Channels;
using MQTTnet.Client;
using System;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using MQTTnet.Protocol;
using Google.Protobuf.WellKnownTypes;
using Google.Protobuf.Protocol;
using System.Collections.Concurrent;
using System.Numerics;
using System.Diagnostics;
using System.Collections.Generic;

namespace MQTT_Broker
{
    public class Broker
    {
        const string RegistInpo = "factory/register";

        public static Broker Instance => _instance.Value;
        private static readonly Lazy<Broker> _instance = new Lazy<Broker>(() => new Broker());

        //public SensorBatchProcessor SBP { get { return SBProcessor; } }
        private SensorBatchProcessor SBProcessor = new SensorBatchProcessor();

        MqttFactory mqttFactory = new MqttFactory();
        MqttServerOptions mqttServerOptions = new MqttServerOptions();
        public MqttServer MQTTServer { get { return server; } }
        MqttServer server = null;

        ConcurrentDictionary<int, VirtualSensor> VirtualSensorDic  =
                    new ConcurrentDictionary<int, VirtualSensor>();

        ConcurrentDictionary<int,RealSensor> RealSensorTopicDIC =
                    new ConcurrentDictionary<int, RealSensor>();

        public Broker(int Port = 1883)
        {
            // 1. 브로커 기본 옵션 구성 (포트, 연결 제한 등)
            mqttServerOptions = mqttFactory.CreateServerOptionsBuilder()
                                           .WithDefaultEndpoint()
                                           .WithDefaultEndpointPort(Port)
                                           .WithMaxPendingMessagesPerClient(20)
                                           .Build();

            server = mqttFactory.CreateMqttServer(mqttServerOptions);
            SBProcessor.Start();

            Register_ConnectEvnet();
            Register_SubsctipyEvent();
            Register_Recieved_Event();
        }

        public SensorInpos PublishSensoerInpo()
        {
            SensorInpos sensorInpos = new SensorInpos();
            foreach(var sensorinpo in VirtualSensorDic.Values)// 500개 이상 보낼 때는 주의 할 것
            {
                SensorInpo sinpo = new SensorInpo();
                sinpo.ID = sensorinpo.ID;
                sinpo.Type = sensorinpo.Type;
                sinpo.Topic = sensorinpo.Topic;

                sinpo.X = sensorinpo.pos.X;
                sinpo.Y = sensorinpo.pos.Y;
                sinpo.Z = sensorinpo.pos.Z;

                sinpo.Rotx = sensorinpo.rot.X;
                sinpo.Roty = sensorinpo.rot.Y;
                sinpo.Rotz = sensorinpo.rot.Z;

                sensorInpos.Info.Add(sinpo);
            }

            foreach (var sensorinpo in RealSensorTopicDIC.Values)
            {
                SensorInpo sinpo = new SensorInpo();
                sinpo.ID = sensorinpo.ID;
                sinpo.Topic = sensorinpo.Topic;
                sinpo.Type = sensorinpo.Type;
                sensorInpos.Info.Add(sinpo);
            }
            return sensorInpos;
        }

        // 딕셔너리 순회 없이 단 한 번의 호출로 끝
        public async Task FastBroadcastAsync(string payload)
        {
            var message = new MqttApplicationMessageBuilder()
                .WithTopic("sensor/broadcast/cmd") // 공통 브로드캐스트 토픽
                .WithPayload(payload)
                .Build();

            await server.InjectApplicationMessage(
                new InjectedMqttApplicationMessage(message) { SenderClientId = "Broker" }
            );
        }

        public void Register_ConnectEvnet()
        {
            server.ClientConnectedAsync += async e =>
            {
                Console.WriteLine($"[연결] 클라이언트 ID: {e.ClientId} (IP: {e.Endpoint})");
                await Task.CompletedTask;
            };
        }

        ////2.인증 / 인가 로직 세부 조정
        //인증이 안되면 .InterceptingPublishAsync가 동작하지 않음
        //server.ValidatingConnectionAsync += e =>
        //{
        //    if (e.UserName != "admin" || e.Password != "secret123")
        //    {
        //        e.ReasonCode = MQTTnet.Protocol.MqttConnectReasonCode.BadUserNameOrPassword;
        //    }

        //    Console.WriteLine($"[연결] 클라이언트 ID: { e.UserName } (IP: { e.Password })");
        //    return Task.CompletedTask;
        //};

        public void Register_SubsctipyEvent()
        {
            server.InterceptingSubscriptionAsync += async e =>
            {
                try
                {
                    // 정상 구독 승인 (QoS 설정 유지)
                    e.Response.ReasonCode = MqttSubscribeReasonCode.GrantedQoS1;//GrantedQoS0
                    e.ProcessSubscription = true;
                }
                catch
                {
                    e.ProcessSubscription = false;
                    e.Response.ReasonCode = MqttSubscribeReasonCode.NotAuthorized;
                }
                await Task.CompletedTask;
            };
        }

        public async Task SendToSensorAsync(string topic, string payload)
        {
            // 3. 전달할 메시지 생성
            var message = new MqttApplicationMessageBuilder()
                              .WithTopic(topic)
                              .WithPayload(payload)
                              .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.AtLeastOnce)//AtMostOnce
                              .WithRetainFlag(false)
                              .Build();

            var injected = new InjectedMqttApplicationMessage(message)
            {
                SenderClientId = "Broker"
            };

            try
            {
                await server.InjectApplicationMessage(injected).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"MQTT 전송 오류: {ex.Message}");
            }
        }

        public void Register_Recieved_Event()
        {
            server.InterceptingPublishAsync += async e =>
            {
                if (string.Equals(e.ClientId, "Broker", StringComparison.Ordinal))
                    return;

                var topic = e.ApplicationMessage.Topic;
                var barr = e.ApplicationMessage.PayloadSegment;

                if (barr.Array == null)
                {
                    e.ProcessPublish = false;
                    return;
                }

                string payload = Encoding.UTF8.GetString(barr.Array, barr.Offset, barr.Count);
                //RegistInpo = "factory/register";
                //센서 정보가 들어왔을 때
                if (string.Equals(RegistInpo, topic, StringComparison.Ordinal))
                {
                    string[] result = payload.Split('|', StringSplitOptions.RemoveEmptyEntries);
                    if (result.Length <= 2)//최소 길이3
                        return;

                    int Key = ConvertUtil.ToInt(result[0]);
                    int Type = ConvertUtil.ToInt(result[1]);

                    if (Key == int.MaxValue || Type == int.MaxValue)
                    {
                        e.ProcessPublish = false;
                        return;
                    }

                    //0이면 리얼센서
                    if(ConvertUtil.ToInt(result[result.Length -1]) == 0)
                    {
                        var RS = new RealSensor() 
                        { ID = Key, Type = Type, Topic = result[2] };

                        RealSensorTopicDIC.TryAdd(Key, RS);

                        SensorInpo SINPO = new SensorInpo();
                        SINPO.ID = RS.ID;
                        SINPO.Type = RS.Type;
                        SINPO.Topic = RS.Topic;

                        BackEndSession.Default.Send(SINPO);
                        e.ProcessPublish = false;
                        return;
                    }

                    var SData = new VirtualSensor()
                    {
                        ID = Key, Type = Type,Topic = result[2],
                        pos = new Vector3(ConvertUtil.ToFloat(result[3]),
                                          ConvertUtil.ToFloat(result[4]),
                                          ConvertUtil.ToFloat(result[5])),

                        rot = new Vector3(ConvertUtil.ToFloat(result[6]),
                                          ConvertUtil.ToFloat(result[7]),
                                          ConvertUtil.ToFloat(result[8]))
                    };

                    VirtualSensorDic.TryAdd(Key, SData);

                    SensorInpo sinpo = new SensorInpo();
                    sinpo.ID = SData.ID; sinpo.Type = SData.Type; sinpo.Topic = SData.Topic;
 
                    sinpo.X = SData.pos.X; sinpo.Y = SData.pos.Y; sinpo.Z = SData.pos.Z;
                    sinpo.Rotx = SData.rot.X; sinpo.Roty = SData.rot.Y; sinpo.Rotz = SData.rot.Z;

                    //혹시나 늦게 등록되는 경우
                    BackEndSession.Default.Send(sinpo);
                }
                else
                {
                    // 문자배열 마지막'/' 뒤에 있는 모든 문자를 추출하는 코드
                    //ex) "Factory/Sensor/123" -> "123"
                    string result = topic.Substring(topic.LastIndexOf('/') + 1);
                    int ID = ConvertUtil.ToInt(result);

                    if (ID == int.MaxValue)
                    {
                        e.ProcessPublish = false;
                        return;
                    }

                    SBProcessor.Enqueue(new SensorMessage(ID, topic, payload));
                    Console.WriteLine($"[수신] Topic: {topic}, Payload: {payload}");
                }
                e.ProcessPublish = false;
            };
        }
    }
}