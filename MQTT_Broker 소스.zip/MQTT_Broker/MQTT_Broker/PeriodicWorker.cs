﻿using MQTT_Broker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//백엔드 패킷 실행자
public class PeriodicWorker
{
    private readonly CancellationTokenSource _cts = new CancellationTokenSource();

    public void Start(int ms_interval = 100)
    {
        Task.Run(async () =>
        {
            using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(ms_interval));

            try
            {
                while (await timer.WaitForNextTickAsync(_cts.Token))
                {
                    Work();
                }
            }
            catch (OperationCanceledException)
            {
               
            }
        });
    }

    public void Stop() => _cts.Cancel();

    public void Work()
    {
        var mesList = PacketQueue.Instance.PopAll();
        foreach (var tmp in mesList)
        {
            var SBC = tmp;
            if (SBC == null)
                return;

            var Action = ServerCommandHandle.GetAction(SBC.Id);
            if (Action == null)
                continue;

            Action.Invoke(SBC.Message);
        }
    }
}