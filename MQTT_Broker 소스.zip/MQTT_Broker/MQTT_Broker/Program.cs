﻿using MQTTnet.Client;
using MQTTnet;
using MQTTnet.Server;
using MQTTnet.Protocol;
using System;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using Google.Protobuf;
using Google.Protobuf.Protocol;

namespace MQTT_Broker
{
    internal class Program  
    {
        public static IPEndPoint BrokerEndPoint = null;

        static async Task Main(string[] args)
        {
            Listener listener = new Listener();
            //IP셋팅
            listener.Init();

            //백엔드에서 온 패킷 실행자
            var BackWorker = new PeriodicWorker();
            BackWorker.Start();

            Broker.Instance.MQTTServer.StartAsync().GetAwaiter().GetResult();
            Console.WriteLine("MQTT 브로커 실행...");
            await Task.Delay(-1);
        }
    }
}