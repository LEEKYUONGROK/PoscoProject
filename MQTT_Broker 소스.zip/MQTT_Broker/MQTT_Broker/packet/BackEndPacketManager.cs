using Google.Protobuf;
using Google.Protobuf.Protocol;
using MQTT_Broker;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;

class BackEndPacketManager
{
    const string FactoryTopic = "factory/receive";
    public static BackEndPacketManager Instance { get { return _instance; } }
    static BackEndPacketManager _instance = new BackEndPacketManager();

	BackEndPacketManager()
	{
		Register();
	}

	Dictionary<ushort, Action<ArraySegment<byte>, ushort>>_onRecv 
		= new Dictionary<ushort, Action<ArraySegment<byte>, ushort>>();

    public void Register()
	{
        _onRecv.Add((ushort)MsgId.ClientCommand, MakePacket<ClientCommand>);
		ServerCommandHandle.ADDCommand((ushort)MsgId.ClientCommand, ClientCommand);

        _onRecv.Add((ushort)MsgId.SensorInpoRequest, MakePacket<SensorInpoRequest>);
		ServerCommandHandle.ADDCommand((ushort)MsgId.SensorInpoRequest, RequestSensorDatas);
    }


    public async void ClientCommand(IMessage msg)
	{
		ClientCommand CM = msg as ClientCommand;
		if (CM == null)
			return;

        string playload = $"{CM.SensorID}|{CM.ToTopic}|{CM.CommandId}";
        if (CM.ToFactory)
		{
			await Broker.Instance.SendToSensorAsync(FactoryTopic, playload);
		}
		else
		{
            await Broker.Instance.SendToSensorAsync(CM.ToTopic, playload);
        }
    }
    public void RequestSensorDatas(IMessage msg)
    {
		SensorInpoRequest rsd = msg as SensorInpoRequest;
		if (rsd == null) 
			return;

		var MSG = Broker.Instance.PublishSensoerInpo();
        BackEndSession.Default.Send(MSG);
    }

    public void OnRecvPacket(ArraySegment<byte> buffer)
	{
		ushort count = 0;

		ushort size = BitConverter.ToUInt16(buffer.Array, buffer.Offset);
		count += 2;
		ushort id = BitConverter.ToUInt16(buffer.Array, buffer.Offset + count);
		count += 2;

		Action<ArraySegment<byte>, ushort> action = null;
		if (_onRecv.TryGetValue(id, out action))
			action.Invoke(buffer, id);
	}

	void MakePacket<T>(ArraySegment<byte> buffer, ushort id) where T : IMessage, new()
	{
		T pkt = new T();
		pkt.MergeFrom(buffer.Array, buffer.Offset + 4, buffer.Count - 4);

        PacketQueue.Instance.Push(id, pkt);
    }
}

/*	public Action<PacketSession, IMessage> GetPacketHandler(ushort id)
	{
		Action<PacketSession, IMessage> action = null;
		if (_handler.TryGetValue(id, out action))
			return action;
		return null;
	}*/