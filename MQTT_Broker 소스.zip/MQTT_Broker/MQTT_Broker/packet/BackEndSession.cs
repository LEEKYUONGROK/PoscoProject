﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using Google.Protobuf.Protocol;
using Google.Protobuf;

namespace MQTT_Broker
{
	public class BackEndSession : PacketSession
	{
        public static BackEndSession Default { get { return _default.Value; } }

        private static Lazy<BackEndSession> _default 
				 = new Lazy<BackEndSession>(() => new BackEndSession());

        public void CreateNew()
        {
            _default = new Lazy<BackEndSession>(() => new BackEndSession());
        }

		public void Send(IMessage packet)
		{
			if (!Default.CheckConnecttion())
				return;

            string msgName = packet.Descriptor.Name.Replace("_", string.Empty);
			MsgId msgId = (MsgId)Enum.Parse(typeof(MsgId), msgName);
			ushort size = (ushort)packet.CalculateSize();

			byte[] sendBuffer = new byte[size + 4];
			Array.Copy(BitConverter.GetBytes((ushort)(size + 4)), 0, sendBuffer, 0, sizeof(ushort));
			Array.Copy(BitConverter.GetBytes((ushort)msgId), 0, sendBuffer, 2, sizeof(ushort));
			Array.Copy(packet.ToByteArray(), 0, sendBuffer, 4, size);
			Send(new ArraySegment<byte>(sendBuffer));
		}

		public override void OnConnected(EndPoint endPoint)
		{
            Console.WriteLine($"OnConnected : { endPoint }");
        }

        public override void OnRecvPacket(ArraySegment<byte> buffer)
		{
			BackEndPacketManager.Instance.OnRecvPacket(buffer);
		}

		public override void OnSend(int numOfBytes)
		{
			//Console.WriteLine($"Transferred bytes: {numOfBytes}");
		}
	}
}
