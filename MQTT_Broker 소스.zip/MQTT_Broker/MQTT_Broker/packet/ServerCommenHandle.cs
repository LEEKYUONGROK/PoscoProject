﻿using Google.Protobuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace MQTT_Broker
{
    internal class ServerCommandHandle
    {
        static Dictionary<ushort,Action<IMessage>> CoommandDic 
            = new Dictionary<ushort,Action<IMessage>>();

        public static void ADDCommand(ushort id, Action<IMessage> action)
        {
            if (CoommandDic.ContainsKey(id) || action == null)
                return;

            CoommandDic.Add(id, action);
        }

        public static Action<IMessage> GetAction(ushort id)
        {
            Action<IMessage> action = null;
            if (CoommandDic.TryGetValue(id, out action))
                return action;

            return null;
        }
    }
}
