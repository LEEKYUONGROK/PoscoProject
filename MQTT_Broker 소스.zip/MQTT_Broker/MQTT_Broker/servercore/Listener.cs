﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Numerics;
using System.Text;

namespace MQTT_Broker
{
	public class Listener
	{
		Socket _listenSocket = null;
        public void Init(int backlog = 1)
        {
            IPAddress ipAddress = IPAddress.Any;
            IPEndPoint EndPoint = new IPEndPoint(ipAddress, 8888);

            _listenSocket = new Socket(EndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            _listenSocket.Bind(EndPoint);
            _listenSocket.Listen(backlog);

            SocketAsyncEventArgs args = new SocketAsyncEventArgs();
            args.Completed += new EventHandler<SocketAsyncEventArgs>(OnAcceptCompleted);
            RegisterAccept(args);
		}

		void RegisterAccept(SocketAsyncEventArgs args)
		{
			args.AcceptSocket = null;

			bool pending = _listenSocket.AcceptAsync(args);
			if (pending == false)
				OnAcceptCompleted(null, args);
		}

        void OnAcceptCompleted(object sender, SocketAsyncEventArgs args)
		{
			if (args.SocketError == SocketError.Success && args.AcceptSocket != null 
				&& args.AcceptSocket.RemoteEndPoint is IPEndPoint remoteEndPoint)
			{
                string clientIp = remoteEndPoint.Address.ToString();
                IPAddress ipAddress = IPAddress.Parse(clientIp);

                if (BackEndSession.Default != null &&
                    BackEndSession.Default.CheckConnecttion())
                    //아직 연결중인데 연결 신호가 오면 무시
                    return;

                BackEndSession.Default.CreateNew();
                BackEndSession.Default.Start(args.AcceptSocket);
                Console.WriteLine("연결 성공");


                //if (ipAddress.AddressFamily == AddressFamily.InterNetworkV6)
                //{
                //    //TODO 지정ip가 아닌 곳에서 연결 시도시 무시

                //}
                //else
                //{
                //    Console.WriteLine("IPv4주소");
                //}
            }
			
			RegisterAccept(args);
		}
	}
}
