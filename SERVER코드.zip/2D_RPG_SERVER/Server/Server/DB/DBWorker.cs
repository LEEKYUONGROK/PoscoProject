﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Google.Protobuf;
using Google.Protobuf.Protocol;
using System.Net.Sockets;

namespace Server
{

    public class DBWorker
    {
        const int QUEUE_SIZE = 1000;
        private BlockingCollection<IJob> _queue 
                   = new BlockingCollection<IJob>(QUEUE_SIZE);

        private readonly Thread _workerThread;

        public DBWorkerJobs DBJobCommand { get; private set; }
        public DBWorker()
        {
            DBJobCommand = new DBWorkerJobs();
            _workerThread = new Thread(ProcessLoop) { IsBackground = true };
            _workerThread.Start();
        }

        // 1. 큐에 작업을 쌓는 메서드 (여러 스레드에서 호출 가능)
        public void Enqueue(IJob task)
        {
            if (!_queue.IsAddingCompleted)
            {
                _queue.Add(task);
            }
        }

        public bool TryEnqueue(IJob task)
        {
            if (_queue.IsAddingCompleted)
                return false;

            // 큐가 꽉 찼으면 기다리지 않고 즉시 false를 반환
            bool isSuccess = _queue.TryAdd(task);

            if (!isSuccess)
            {
                // 필요한 처리: 사용자에게 에러 반환, 로그 기록 등
                Console.WriteLine("경고: DB 작업 큐가 꽉 찼습니다!");
            }

            return isSuccess;
        }

        private void ProcessLoop()
        {
            try
            {
                // GetConsumingEnumerable()은 큐에 데이터가 최소 1개 들어올 때까지 스레드를 대기(Block) 시킵니다.
                foreach (var firstTask in _queue.GetConsumingEnumerable())
                {
                    firstTask.Execute();
                    // TryTake는 대기하지 않고 큐에 있는 항목을 즉시 꺼냅니다.
                    while (_queue.TryTake(out var nextTask))
                    {
                        nextTask.Execute();
                    }
                }
            }
            catch (ObjectDisposedException)
            {
                Console.WriteLine("DB잡업 큐에서 이상발생");
            }
        }

        public void SensorsDataToClient(ClientSession session)
        {
            var msg = DBJobCommand.MakeSInpoMSG();
            Program.CH.Push(session.Send, msg);
        }

        public void SaveSensorsData(IMessage message)
        {
            var SensorsInpo = message as SensorInpos;
            if (SensorsInpo == null)
                return;

            TryEnqueue(new Job<SensorInpos>(DBJobCommand.GetSensorsMsg, SensorsInpo));
        }

        public void SaveLog(SensorsMsg message)
        {
            TryEnqueue(new Job<SensorsMsg>(DBJobCommand.LogMSGSaveProcess, message));
        }
        public void SaveSensor(IMessage message)
        {
            var sensorinpo = message as SensorInpo;
            if (sensorinpo == null)
                return;

            TryEnqueue(new Job<SensorInpo>(DBJobCommand.GetOneSensorMsg, sensorinpo));
        }

        // 애플리케이션 종료 시 안전하게 스레드를 닫는 메서드
        public void Stop()
        {
            _queue.CompleteAdding(); // 더 이상 작업을 받지 않음
            _workerThread.Join();    // 큐에 남은 작업이 모두 처리될 때까지 메인 스레드 대기
            _queue.Dispose();
        }
    }
}