﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using MySqlConnector;
using Google.Protobuf.Protocol;
using System.Numerics;
using System.Collections.Concurrent;
using System.Linq;
using System.Diagnostics;


namespace Server
{
    public class DBWorkerJobs
    {
        Dictionary<string, DBTableInpo> DBInpoDic 
            = new Dictionary<string, DBTableInpo>();

        private int DICMAX_Sensors = -1;
        ConcurrentDictionary<int, sensor> _DicSensors 
            = new ConcurrentDictionary<int, sensor>();

        const string Connect_str
            = "Server=127.0.0.1;Port=3000;User ID=root;Password=1234;Database=Vision4;AllowLoadLocalInfile=true;";

        const string query =
            "INSERT IGNORE INTO sensor (ID, Type, Topic ) VALUES (@id, @type, @topic)";

        private Stopwatch stopwatch = new Stopwatch();
        public DBWorkerJobs()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(Connect_str))
                {
                    conn.Open();
                    GetTableName(conn);

                    foreach (var Table_Inpo in DBInpoDic.Values)
                    {
                        GetTableColumns(conn, Table_Inpo);
                    }

                    DeleteOldLogs();
                    //LoadSensorDatas(conn);
                }
                stopwatch.Restart();
            }
            catch (Exception ex) { Console.WriteLine($"에러 발생: {ex.Message}"); }
        }
        void DeleteOldLogs()
        {
            const int targetCount = 1_800_000;
            const int batchSize = 10_000;

            int totalDeleted = 0;

            try
            {
                using var conn = new MySqlConnection(Connect_str);
                conn.Open();

                using var cmd = new MySqlCommand(@"
                DELETE FROM `sensorlog`
                ORDER BY `DateTime` ASC
                LIMIT @count;", conn);

                cmd.CommandTimeout = 120;
                cmd.Parameters.Add("@count", MySqlDbType.Int32);

                while (totalDeleted < targetCount)
                {
                    int count = Math.Min(batchSize, targetCount - totalDeleted);

                    cmd.Parameters["@count"].Value = count;

                    int deleted = cmd.ExecuteNonQuery();

                    if (deleted == 0)
                        break;

                    totalDeleted += deleted;
                }

                Console.WriteLine($"로그 {totalDeleted:N0}줄 삭제 완료");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"로그 삭제 오류: {ex.Message}");
            }
        }

        public sensor FindSener(int SensorID)
        {
            if (_DicSensors.TryGetValue(SensorID, out sensor value))
                return value;

            return null;
        }

        public bool CheckSensorKey(int Key)
        {
            if (_DicSensors == null)
                return false;

            return _DicSensors.ContainsKey(Key);
        }

        public DBTableInpo GetTableInpo(string Key)
        {
            if (DBInpoDic.TryGetValue(Key, out DBTableInpo value)) 
                return value;

            return null;
        }

        public void GetOneSensorMsg(SensorInpo sensorinpo)
        {
            // SensorInpo의 포지션과 로테이션 값을 Vector3로 변환
            var pos = new Vector3(sensorinpo.X, sensorinpo.Y, sensorinpo.Z);
            var rot = new Vector3(sensorinpo.Rotx, sensorinpo.Roty, sensorinpo.Rotz);

            // sensor 객체 생성 시 포지션과 로테이션 값을 전달
            if (_DicSensors.TryAdd(sensorinpo.ID, 
                        new sensor(sensorinpo.ID, sensorinpo.Type, sensorinpo.Topic, pos, rot)))
            {
                if (sensorinpo.ID > DICMAX_Sensors)
                    DICMAX_Sensors = sensorinpo.ID;

                using (MySqlConnection conn = new MySqlConnection(Connect_str))
                {
                    try
                    {
                        conn.Open();
                        using (MySqlCommand cmd = new MySqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@id", sensorinpo.ID);
                            cmd.Parameters.AddWithValue("@type", sensorinpo.Type);
                            cmd.Parameters.AddWithValue("@topic", sensorinpo.Topic);

                            cmd.ExecuteNonQuery();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Sensor DB저장 실패");
                    }
                }
                Program.CH.Push(Program.CH.Broadcast, sensorinpo);
                Console.WriteLine("센서 새로등록");
            }
            else
            {
                Console.WriteLine("이미 존재하는 센서");
            }
        }
        public void GetSensorsMsg(SensorInpos SensorsInpo)
        {
            var TableInpo = GetTableInpo(typeof(sensor).Name);

            if (TableInpo == null)
            {
                Console.WriteLine("Make Talbe Fail");
                return;
            }

            DataTable dataTable = new DataTable();
            dataTable.TableName = TableInpo.Name;

            //테이블 컬럼 추가
            foreach (var Tmp in TableInpo.Columns)
                     dataTable.Columns.Add(Tmp.Key, Tmp.Value);

            foreach (var sensorinpo in SensorsInpo.Info)
            {
                try
                {
                    var pos = new Vector3(sensorinpo.X, sensorinpo.Y, sensorinpo.Z);
                    var rot = new Vector3(sensorinpo.Rotx, sensorinpo.Roty, sensorinpo.Rotz);

                    if (_DicSensors.TryAdd(sensorinpo.ID,
                        new sensor(sensorinpo.ID, sensorinpo.Type, sensorinpo.Topic, pos, rot)))//, sensorinpo.BelongFactory, sensorinpo.Floor)))
                    {
                        if (sensorinpo.ID > DICMAX_Sensors)
                            DICMAX_Sensors = sensorinpo.ID;

                        dataTable.Rows.Add
                            (sensorinpo.ID, sensorinpo.Type, sensorinpo.Topic);
                    }
                }
                catch
                {
                    Console.WriteLine("1 row Save Fail");
                    continue;
                }
            }
            SaveProcesser(dataTable);
        }


       
        public void LogMSGSaveProcess(SensorsMsg SaveDatas)
        {
            var TableInpo = GetTableInpo(typeof(sensorlog).Name);

            if (TableInpo == null)
            {
                Console.WriteLine("Make Talbe Fail");
                return;
            }

            DataTable dataTable = new DataTable();
            dataTable.TableName = TableInpo.Name;

            foreach (var Tmp in TableInpo.Columns)
                dataTable.Columns.Add(Tmp.Key, Tmp.Value);

            bool Fire = false; bool Danger = false;
            foreach (var SensorLog in SaveDatas.Info)
            {
                try
                {
                    if (SensorLog.SensorID > 300 && 
                        _DicSensors.TryGetValue(SensorLog.SensorID, out sensor value))
                    {
                        if (value.Type == SensorType.FireSensors && 
                            SensorParser.TryParseFireSensors(SensorLog.Msg, out FireSensorsData data))
                        {
                            if (data.fire_alarm > 0)
                                Fire = true;

                            if (data.danger_signal > 0 || data.person_detected > 0)
                            {
                                Danger = true;
                            }

                            if (DateTime.TryParse(data.timestamp, out DateTime Date))
                            {
                                dataTable.Rows.Add(SensorLog.SensorID, SensorLog.Msg, Date);
                            }
                        }
                        else if(value.Type == SensorType.FireCamera)
                        {
                            string[] FireCamResult = SensorLog.Msg.Split('|');
                            if (SensorParser.TryParseResult
                               (FireCamResult[1], out int Result) && Result > 0)
                            {
                                Fire = true;
                            }
                            if (DateTime.TryParse(FireCamResult[2], out DateTime Date))
                            {
                                dataTable.Rows.Add(SensorLog.SensorID, FireCamResult[1], Date);
                            }
                        }
                        else if(value.Type == SensorType.Camera)
                        {
                            if (SensorLog.Msg == null)
                                continue;

                            int index = SensorLog.Msg.LastIndexOf('|');

                            string result = 
                                   index >= 0 ? SensorLog.Msg.Substring(index + 1) : SensorLog.Msg;

                            if (result == null)
                                continue;

                            SensorLog.Msg = $"{Default.InspecResult}:{result}";
                            dataTable.Rows.Add(SensorLog.SensorID, SensorLog.Msg, DateTime.Now);
                        }
                    }
                    else
                    {
                        string[] result = SensorLog.Msg.Split('|');

                        if (DateTime.TryParse(result[1], out DateTime DT))
                        {
                            dataTable.Rows.Add(SensorLog.SensorID, result[0], DT);
                        }
                    }

                }
                catch
                {
                    Console.WriteLine("Save Fail");
                    continue;
                }
            }

            if(DICMAX_Sensors > Default.RealSenStart)
            {
                if (Fire)
                {
                    ClientCommand msg = new ClientCommand();
                    msg.CommandId = 1;
                    msg.ToTopic = "RealSensor/301";
                    msg.ToFactory = false;
                    Program.CH.Push(MqttManager.Instance.Send, msg);

                    ClientCommand msg2 = new ClientCommand();
                    msg2.CommandId = 1;
                    msg2.ToTopic = "RealSensor/302";
                    msg.ToFactory = false;
                    Program.CH.Push(MqttManager.Instance.Send, msg2);
                }
                else if (Danger)
                {
                    ClientCommand msg = new ClientCommand();
                    msg.CommandId = 1;
                    msg.ToTopic = "RealSensor/301";
                    msg.ToFactory = false;
                    Program.CH.Push(MqttManager.Instance.Send, msg);
                }
                else if (stopwatch.ElapsedMilliseconds > Default.WaitMS)
                {
                    ClientCommand msg = new ClientCommand();
                    msg.CommandId = 0;
                    msg.ToTopic = "RealSensor/301";
                    msg.ToFactory = false;
                    Program.CH.Push(MqttManager.Instance.Send, msg);

                    ClientCommand msg2 = new ClientCommand();
                    msg2.CommandId = 0;
                    msg2.ToTopic = "RealSensor/302";
                    msg.ToFactory = false;
                    Program.CH.Push(MqttManager.Instance.Send, msg2);
                }
                stopwatch.Restart();
            }
            SaveProcesser(dataTable);
        }

        //데이터테이블 DB에 저장
        void SaveProcesser(DataTable table)
        {
            try
            {
                using var conn = new MySqlConnection(Connect_str);
                conn.Open();

                var bulkCopy = new MySqlBulkCopy(conn);

                bulkCopy.DestinationTableName = table.TableName;
                bulkCopy.ConflictOption = MySqlBulkLoaderConflictOption.Ignore;

                var result = bulkCopy.WriteToServer(table);
                Console.WriteLine($"{table.TableName}테이블 {result.RowsInserted}행  저장 성공");
            }
            catch { Console.WriteLine("테이블 저장 실패"); }
        }

        public SensorInpos MakeSInpoMSG()
        {
            SensorInpos SensorsMsg = new SensorInpos();

            if (_DicSensors.Count == 0)
                Console.WriteLine("Sensor DIc is null");
            
            foreach (var sinpo in _DicSensors.Values)
            {
                var sensorinpo = new SensorInpo();
                sensorinpo.ID = sinpo.ID;
                sensorinpo.Topic = sinpo.Topic;
                sensorinpo.Type = (int)sinpo.Type;
                sensorinpo.X = sinpo.pos.X;
                sensorinpo.Y = sinpo.pos.Y;
                sensorinpo.Z = sinpo.pos.Z;
                sensorinpo.Rotx = sinpo.rot.X;
                sensorinpo.Roty = sinpo.rot.Y;
                sensorinpo.Rotz = sinpo.rot.Z;

                SensorsMsg.Info.Add(sensorinpo);
            }
            return SensorsMsg;
        }

        public void LoadSensorDatas(MySqlConnection conn)
        {
            string SensorTable = "SELECT * FROM sensor";
            using (MySqlCommand colCmd = new MySqlCommand(SensorTable, conn))
            {
                using (MySqlDataReader colReader = colCmd.ExecuteReader())
                {
                    int ID_Index = colReader.GetOrdinal("ID");
                    int Type_Index = colReader.GetOrdinal("Type");
                    int Topic_Index = colReader.GetOrdinal("Topic");

                    while (colReader.Read())
                    {
                        int SensorID = colReader.GetInt32(ID_Index);

                        //_DicSensors.TryAdd(SensorID,
                        //       new sensor(SensorID, colReader.GetInt32(Type_Index), colReader.GetString(Topic_Index),
                        //                   colReader.GetInt32(FactoryNum_Index), colReader.GetInt32(Floor_Index)));
                    }
                }
            }
        }

        //테이블 이름을 불러온다.
        public void GetTableName(MySqlConnection conn)
        {
            using (MySqlCommand tableCmd = new MySqlCommand(Default.GetTableNameSQL, conn))
            {
                using (MySqlDataReader tableReader = tableCmd.ExecuteReader())
                {
                    //int ID_Index = 0;
                    while (tableReader.Read())
                    {
                        string tableName = tableReader.GetString("TABLE_NAME");
                        var NewTable = new DBTableInpo();
                        NewTable.Name = tableName;
                        //NewTable.ID = ID_Index++;

                        DBInpoDic.Add(NewTable.Name, NewTable);
                    }
                }
            }
        }

        //테이블 속성을 불러온다
        public void GetTableColumns(MySqlConnection conn,DBTableInpo TableInpo)
        {
            string GetColumns = $"SELECT * FROM {TableInpo.Name} LIMIT 0";
            using (MySqlCommand colCmd = new MySqlCommand(GetColumns, conn))
            {
                using (MySqlDataReader colReader = colCmd.ExecuteReader())
                {
                    for (int i = 0; i < colReader.FieldCount; i++)
                    {
                        string colName = colReader.GetName(i);
                        Type colType = colReader.GetFieldType(i);
                        TableInpo.Columns.Add(colName, colType);
                    }
                }
            }
        }

        public void WarmUp()
        {
            using (MySqlConnection conn = new MySqlConnection(Connect_str))
            {
                try
                {
                    conn.Open();
                    Console.WriteLine("MariaDB에 성공적으로 연결되었습니다!");
                  
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"에러 발생: {ex.Message}");
                }
            }
        }
        
    }
}

//var bulkCopy = new MySqlBulkCopy(connection)
//{
//    DestinationTableName = table.TableName

//};