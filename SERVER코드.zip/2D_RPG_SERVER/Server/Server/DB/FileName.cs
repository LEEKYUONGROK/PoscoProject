﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;


public class FireSensorsData
{

    public int danger_signal { get; set; }
    public int flame_detected { get; set; }
    public int fire_alarm { get; set; }
    public int alarm_level { get; set; }

    public float temperature_c { get; set; }
    public float humidity_pct { get; set; }

    public int mq2 { get; set; }
    public int mq7 { get; set; }

    public int person_detected { get; set; }
    public int dht_ok { get; set; }

    public string timestamp { get; set; }
}

public class FireCamera
{
    public int result { get; set; }
}


public static class SensorParser
{
    public static bool TryParseResult(
        string json,
        out int result)
    {
        result = 0;

        if (string.IsNullOrWhiteSpace(json))
            return false;

        try
        {
            FireCamera data =
                JsonSerializer.Deserialize<FireCamera>(json);

            if (data == null)
                return false;

            result = data.result;
            return true;
        }
        catch (JsonException)
        {
            return false;
        }
    }


    public static bool TryParseFireSensors(
        string json,
        out FireSensorsData data)
    {
        data = null;

        if (string.IsNullOrWhiteSpace(json))
            return false;

        try
        {
            data = JsonSerializer.Deserialize<FireSensorsData>(json);
            return data != null;
        }
        catch (JsonException)
        {
            return false;
        }
    }
}
