﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Net.Http.Headers;
using Google.Protobuf.Protocol;
using Google.Protobuf;
using MySqlConnector;
using System.Numerics;


namespace Server
{
    //테이블 이름과 일치하는 이름
    public class sensor
    {
        public int ID { get; set; }
        public string Topic { get; set; }
        public SensorType Type { get; set; }
        public Vector3 pos { get; set; }
        public Vector3 rot { get; set; }

        public sensor(int SensorID, int Type, string topic,Vector3 Pos, Vector3 Rot)
        {
            this.ID = SensorID;
            this.Topic = topic;

            if (Enum.IsDefined(typeof(SensorType), Type))
                this.Type = (SensorType)Type;
            else
                this.Type = default;

            pos = Pos;
            rot = Rot;
        }
    }

    public class sensorlog
    {

        public sensorlog() { }
        public sensorlog(int SensorID, string Msg, DateTime DateTime)
        {
            this.SensorID = SensorID;
            this.Msg = Msg;
            this.DateTime = DateTime;
        }
        public int SensorID { get; set; }
        public string Msg { get; set; }
        public DateTime DateTime { get; set; }
    }
}
