﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace Server
{
    public enum Log
    {
        Normal = 0,
        Warning = 1,
        Critical = 2,
    }
    public enum SensorType
    {
        Temperature = 0,
        Conveyor = 1,
        Camera = 2,
        FireSensors = 3,

        FireCamera = 5,
    }
    public class DBTableInpo
    {
        //public int ID { get; set; }
        public string Name { get; set; }
        public Dictionary<string, Type> Columns { get; set; } 
            = new Dictionary<string, Type>();
    }

    internal class Default
    {
        public const string GetTableNameSQL =
            @"SELECT TABLE_NAME 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = ""vision4"" AND TABLE_TYPE = 'BASE TABLE'";

        
        public const string sql = @"SELECT * FROM {TableName}";
        public const string InspecResult = "\"Inspection result\"";
        public const int WaitMS = 500;
        public const int RealSenStart = 300;
        public const int RecvBufferSize = 65535;
        public const int CheckInterval = 100;
        public const int Retry_Interval = 1000;
    }
}
