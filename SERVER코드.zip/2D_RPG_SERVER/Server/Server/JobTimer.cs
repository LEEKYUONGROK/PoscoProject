﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server
{
	struct JobTimerElem : IComparable<JobTimerElem>
	{
		public int execTick; // 실행 시간
		public IJob action;

		public int CompareTo(JobTimerElem other)
		{
			return other.execTick - execTick;
		}
	}

	public class JobTimer
	{
		PriorityQueue<JobTimerElem> _pq = new PriorityQueue<JobTimerElem>();
		object _lock = new object();

		public void Push(IJob job, int tickAfter = 0)
		{
			JobTimerElem JobElement;
            JobElement.execTick = System.Environment.TickCount + tickAfter;
            JobElement.action = job;

			lock (_lock)
			{
				_pq.Push(JobElement);
			}
		}

		public void Flush()
		{
			while (true)
			{
				//int now = System.Environment.TickCount;
				JobTimerElem JobElement;

				lock (_lock)
				{
					if (_pq.Count == 0)
						break;

                    JobElement = _pq.Peek();

					//*예약된 시간이 현재보다 크면 나중에 실행
					//if (JobElement.execTick > now)
					//	break;

					_pq.Pop();
				}

                JobElement.action.Execute();
			}
		}
	}
}
