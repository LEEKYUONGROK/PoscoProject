﻿using Google.Protobuf;
using Google.Protobuf.Protocol;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Text;

namespace Server
{
    public class BrokerPacketManager
    {
        public static BrokerPacketManager Instance { get { return _instance; } }
        static BrokerPacketManager _instance = new BrokerPacketManager();

        Dictionary<ushort, Action<MqttSession, ArraySegment<byte>, ushort>> _onRecv =
                   new Dictionary<ushort, Action<MqttSession, ArraySegment<byte>, ushort>>();

        Dictionary<ushort, Action<IMessage>> _handler = new Dictionary<ushort, Action<IMessage>>();

        BrokerPacketManager()
        {
            Register();
        }

        public void Register()
        {
            _onRecv.Add((ushort)MsgId.SensorsMsg, MakePacket<SensorsMsg>);
            _handler.Add((ushort)MsgId.SensorsMsg, PacketHandler.SensorsLog);

            _onRecv.Add((ushort)MsgId.SensorInpos, MakePacket<SensorInpos>);
            _handler.Add((ushort)MsgId.SensorInpos, PacketHandler.SensorsInpo);

            _onRecv.Add((ushort)MsgId.SensorInpo, MakePacket<SensorInpo>);
            _handler.Add((ushort)MsgId.SensorInpo, PacketHandler.SensorInpo);
        }

        public void OnRecvPacket(MqttSession session, ArraySegment<byte> buffer)
        {
            ushort count = 0;

            ushort size = BitConverter.ToUInt16(buffer.Array, buffer.Offset);
            count += 2;
            ushort id = BitConverter.ToUInt16(buffer.Array, buffer.Offset + count);
            count += 2;

            Action<MqttSession, ArraySegment<byte>, ushort> action = null;
            if (_onRecv.TryGetValue(id, out action))
                action.Invoke(session, buffer, id);
        }

        void MakePacket<T>(MqttSession session, ArraySegment<byte> buffer, ushort id) where T : IMessage, new()
        {
            T pkt = new T();
            pkt.MergeFrom(buffer.Array, buffer.Offset + 4, buffer.Count - 4);

            Action<IMessage> action = null;
            if (_handler.TryGetValue(id, out action))
                action.Invoke(pkt);
        }
    }
}
