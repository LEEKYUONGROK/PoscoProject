﻿using Google.Protobuf;
using Google.Protobuf.Protocol;
using Server;
using System;

class PacketHandler
{


    //브로커 콜백 함수

    //sensorsLog
    public static void SensorsLog(IMessage packet)
    {
        var sensorLog = packet as SensorsMsg;
        if (sensorLog == null)
            return;

        Program.worker.SaveLog(sensorLog);
        //sensor id로 화재센서를 알아내서 화재상황인지 알려야함
        //MqttManager.Instance.Send
        //foreach( in sensorLog.Info)

        Program.CH.Push(Program.CH.Broadcast, sensorLog);
    }

    public static void SensorInpo(IMessage packet)
    {
        Program.worker.SaveSensor(packet);
    }

    public static void SensorsInpo(IMessage packet)
    {
        Program.worker.SaveSensorsData(packet);
    }

    public static void ReciveReport(PacketSession session, IMessage packet)
    {
        ClientSession clientSession = session as ClientSession;
        if (clientSession == null)
            return;

        Program.CH.Push(Program.CH.ExceptMeBroadcast, packet, clientSession);
    }
    //ClientMSG 콜백 함수
    public static void RequestSensorDatas(PacketSession session, IMessage packet)
    {
        ClientSession clientSession = session as ClientSession;
        if (clientSession == null)
            return;

        //work가 DB작업
        Program.worker.TryEnqueue(
            new Job<ClientSession>(Program.worker.SensorsDataToClient, clientSession));
    }
    
    public static void ClientCommand(PacketSession session, IMessage packet)
    {
        ClientSession clientSession = session as ClientSession;
        if (clientSession == null)
            return;

        Program.CH.Push(MqttManager.Instance.Send, packet);
    }
}

/* public static void C_ChageAni(PacketSession session, IMessage packet)
    {
        //Moving,skill은 보내지 말기
        C_Ani Ani = packet as C_Ani;
        ClientSession clientSession = session as ClientSession;

        Player player = clientSession.MyPlayer;

        if (player == null)
            return;

        GameRoom room = player.Room;
        if (room == null)
            return;
    }*/