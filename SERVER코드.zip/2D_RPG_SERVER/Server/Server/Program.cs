﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Threading;
using System.Security.Cryptography.X509Certificates;


namespace Server
{
	class Program
	{
        //서버채널
        public static BackEnd_CH CH = new BackEnd_CH();
        //DB작업자
        public static DBWorker worker = new DBWorker();

        static void Main(string[] args)
        {
            //브로커와 연결
            //"3.39.173.120"
            //"192.168.10.224"
            IPAddress localAddr = IPAddress.Loopback;
            MqttManager.Instance.EndPoint = new IPEndPoint(localAddr, 8888);
            _ = MqttManager.Instance.StartAsync();

            //앱과 통신 셋팅
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, 7777);
            Listener _listener = new Listener();
            _listener.Init(endPoint);

            Console.WriteLine("Listening...");

            //Main스레드 루프
            while (true)
            {
                CH.Update();
            }
        }
	}
}

//Task ConnectCheckTask = new Task(() => 
//{
//    if (MqttSession.BS.CheckDisconnectedFucn() 
//    || !MqttSession.BS.CheckSocketLive())
//    { 
//        //연결이 죽어있을때
//        Connector.Instance.Connect();
//    }
//    Task.Delay(Defualt.CheckInterval);
//},TaskCreationOptions.LongRunning);

//ConnectCheckTask.Start();