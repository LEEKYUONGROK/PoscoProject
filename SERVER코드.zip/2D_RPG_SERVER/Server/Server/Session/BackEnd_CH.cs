﻿using Google.Protobuf;
using Google.Protobuf.Compiler;
using Google.Protobuf.Protocol;
using Google.Protobuf.WellKnownTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Net;
using System.Numerics;


namespace Server
{
    public class BackEnd_CH : JobSerializer
    {
        uint SessionID = 0;
        static object _lock = new object();

        Dictionary<uint, ClientSession> ChBelongSession = new Dictionary<uint, ClientSession>();

        public void Update()
        {
            Flush();
        }

        public ClientSession ADDSession()
        {
            ClientSession Cclient = new ClientSession();
            lock (_lock)
            {
                ChBelongSession.Add(SessionID, Cclient);
                Cclient.SessionId = SessionID;
                SessionID++;
            }
            return Cclient;
        }

        public void RemoveSession(uint SessionID)
        {
            lock (_lock)
            {
                if (ChBelongSession.Remove(SessionID, out ClientSession session))
                {
                    Console.WriteLine("클라이언트와 연결 끊김");
                    //session.Disconnect();
                }
                else
                {
                    Console.WriteLine("Delete Fail");
                }
            }
        }

        public void ExceptMeBroadcast(IMessage packet, ClientSession publisher)
        {
            foreach (ClientSession p in ChBelongSession.Values)
            {
                if (p != publisher)
                {
                    p.Send(packet);
                    Console.WriteLine(packet);
                }
            }
        }
        public void Broadcast(IMessage packet)
		{
            foreach (ClientSession p in ChBelongSession.Values)
            {
                p.Send(packet);
                Console.WriteLine(packet);
            }
        }
	}
}


/*
		public void SetPlayName(IMessage packet)
		{
			lock (_lock)
			{
                foreach (Player p in _players)
                {
                    p.Session.Send(packet);
                }
            }
        }
*/