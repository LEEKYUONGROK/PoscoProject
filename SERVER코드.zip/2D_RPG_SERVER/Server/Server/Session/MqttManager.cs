﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Google.Protobuf;
using Google.Protobuf.Protocol;

namespace Server
{
    public class MqttManager
    {
        public static MqttManager Instance { get { return _instance; } }
        private static MqttManager _instance = new MqttManager();

        object _sessionLock = new object();
        private MqttSession _currentSession = null;

        public EndPoint EndPoint { get { return ENDPoint; } set { ENDPoint = value; } }
        private EndPoint ENDPoint = null;

        public void Send(IMessage packet)
        {
            if (packet != null || _currentSession == null)
                _currentSession.Send(packet);
        }
        public async Task StartAsync()
        {
            while (true)
            {
                try
                {
                    //Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    Socket socket = 
                        new Socket(ENDPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                    await socket.ConnectAsync(ENDPoint);

                    lock (_sessionLock)
                    {
                        _currentSession = new MqttSession(socket, OnSessionDisconnected);
                        _currentSession.Send(new SensorInpoRequest());
                    }
                    Console.WriteLine("브로커와 연결완료");
                    break;
                }
                catch (SocketException ex)
                {
                    //Console.WriteLine($"SocketErrorCode: {ex.SocketErrorCode}"); // 예: ConnectionRefused, TimedOut 등
                    Console.WriteLine($"Message: {ex.Message}");
                }

                await Task.Delay(Default.Retry_Interval); // 재연결 쿨다운
            }
        }

        // 세션이 끊어졌을 때 호출되는 콜백
        private void OnSessionDisconnected(MqttSession closedSession)
        {
            lock (_sessionLock)
            {
                if (_currentSession == closedSession)
                {
                    _currentSession = null;
                    _ = StartAsync();

                    Console.WriteLine("브로커와 재연결 시도");
                }
            }
        }
    }
}
