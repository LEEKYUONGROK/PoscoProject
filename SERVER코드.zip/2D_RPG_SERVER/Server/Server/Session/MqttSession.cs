﻿using Google.Protobuf.Protocol;
using Google.Protobuf;
using Server;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Server
{
    public class MqttSession : IDisposable
    {
        public static readonly int HeaderSize = 2;
        
        Socket _socket;
        int _disconnected = 0;
        object _lock = new object();

        RecvBuffer _recvBuffer = new RecvBuffer(Default.RecvBufferSize);
        Queue<ArraySegment<byte>> _sendQueue = new Queue<ArraySegment<byte>>();
        List<ArraySegment<byte>> _pendingList = new List<ArraySegment<byte>>();

        SocketAsyncEventArgs _sendArgs = new SocketAsyncEventArgs();
        SocketAsyncEventArgs _recvArgs = new SocketAsyncEventArgs();
        // [size(2)][packetId(2)][ ... ][size(2)][packetId(2)][ ... ]

        Action<MqttSession> disConnected_Action = null;
        public MqttSession(Socket socket,Action<MqttSession> action)
        {
            _socket = socket;
            disConnected_Action = action;

            _recvArgs.Completed += new EventHandler<SocketAsyncEventArgs>(OnRecvCompleted);
            _sendArgs.Completed += new EventHandler<SocketAsyncEventArgs>(OnSendCompleted);

            RegisterRecv();
        }

        public int OnRecv(ArraySegment<byte> buffer)
        {
            int processLen = 0;
            int packetCount = 0;

            while (true)
            {
                // 최소한 헤더는 파싱할 수 있는지 확인
                if (buffer.Count < HeaderSize)
                    break;

                //dataSize - 패킷 원본의 크기
                //buffer.Count - 축적된 데이터
                ushort dataSize = BitConverter.ToUInt16(buffer.Array, buffer.Offset);
                if (buffer.Count < dataSize)
                    break;

                // 여기까지 왔으면 패킷 조립 가능
                OnRecvPacket(new ArraySegment<byte>(buffer.Array, buffer.Offset, dataSize));
                packetCount++;

                processLen += dataSize;
                buffer = new ArraySegment<byte>(buffer.Array, buffer.Offset + dataSize, buffer.Count - dataSize);
            }

            if (packetCount > 1)
                Console.WriteLine($"패킷 모아보내기 : {packetCount}");

            return processLen;
        }

        public void Send(IMessage packet)
        {
            string msgName = packet.Descriptor.Name.Replace("_", string.Empty);
            MsgId msgId = (MsgId)Enum.Parse(typeof(MsgId), msgName);
            ushort size = (ushort)packet.CalculateSize();
            byte[] sendBuffer = new byte[size + 4];
            Array.Copy(BitConverter.GetBytes((ushort)(size + 4)), 0, sendBuffer, 0, sizeof(ushort));
            Array.Copy(BitConverter.GetBytes((ushort)msgId), 0, sendBuffer, 2, sizeof(ushort));
            Array.Copy(packet.ToByteArray(), 0, sendBuffer, 4, size);
            Send(new ArraySegment<byte>(sendBuffer));
        }

        public void Send(ArraySegment<byte> sendBuff)
        {
            lock (_lock)
            {
                _sendQueue.Enqueue(sendBuff);
                if (_pendingList.Count == 0)
                    RegisterSend();
            }
        }

        public void OnRecvPacket(ArraySegment<byte> buffer)
        {
            BrokerPacketManager.Instance.OnRecvPacket(this, buffer);
        }

        void Clear()
        {
            lock (_lock)
            {
                _sendQueue.Clear();
                _pendingList.Clear();
            }
        }

        public void Dispose()
        {
            try
            {
                _socket.Shutdown(SocketShutdown.Both);
                _socket.Close();
                Clear();
            }
            catch { }
        }

        void RegisterSend()
        {
            if (_disconnected == 1)
                return;

            while (_sendQueue.Count > 0)
            {
                ArraySegment<byte> buff = _sendQueue.Dequeue();
                _pendingList.Add(buff);
            }
            _sendArgs.BufferList = _pendingList;

            try
            {
                bool pending = _socket.SendAsync(_sendArgs);
                if (pending == false)
                    OnSendCompleted(null, _sendArgs);
            }
            catch (SocketException ex)
            {
                disConnected_Action.Invoke(this);
                switch (ex.SocketErrorCode)
                {
                    case SocketError.ConnectionReset:   // 10054: 상대방이 강제 종료함 (RST)
                    case SocketError.ConnectionAborted: // 10053: 소프트웨어/네트워크에 의해 중단됨
                    case SocketError.Shutdown:          // 10058: 이미 닫힌 소켓으로 전송 시도
                    case SocketError.NotConnected:      // 10057: 연결되지 않은 상태
                        Console.WriteLine("네트워크/소켓 예러");
                        break;

                    case SocketError.TimedOut:          // 10060: 전송 타임아웃
                        Console.WriteLine("응답 대기 시간 초과");
                        break;
                }
            }
            catch (Exception e)//ObjectDisposedException
            {
                disConnected_Action.Invoke(this);
            }
        }

        void OnSendCompleted(object sender, SocketAsyncEventArgs args)
        {
            lock (_lock)
            {
                if (args.BytesTransferred > 0 && args.SocketError == SocketError.Success)
                {
                    _sendArgs.BufferList = null;
                    _pendingList.Clear();
                }
                else
                {
                    disConnected_Action.Invoke(this);
                }
            }
        }

        void RegisterRecv()
        {
            if (_disconnected == 1)
                return;

            _recvBuffer.Clean();
            ArraySegment<byte> segment = _recvBuffer.WriteSegment;
            _recvArgs.SetBuffer(segment.Array, segment.Offset, segment.Count);

            try
            {
                bool pending = _socket.ReceiveAsync(_recvArgs);
                if (pending == false)
                    OnRecvCompleted(null, _recvArgs);
            }
            catch (SocketException ex)
            {
                _disconnected = 1;
                // SocketErrorCode로 끊김 유형 식별
                switch (ex.SocketErrorCode)
                {
                    case SocketError.ConnectionReset:   // 10054: 상대방이 강제 종료함 (RST)
                    case SocketError.ConnectionAborted: // 10053: 소프트웨어/네트워크에 의해 중단됨
                    case SocketError.Shutdown:          // 10058: 이미 닫힌 소켓으로 전송 시도
                    case SocketError.NotConnected:      // 10057: 연결되지 않은 상태
                        Dispose();
                        //연결 재시도 및 소켓 재참조
                        break;

                    case SocketError.TimedOut:          // 10060: 전송 타임아웃
                        Console.WriteLine("응답 대기 시간 초과");
                        break;
                }
            }
            catch (Exception e)
            {
                _disconnected = 1;
                Console.WriteLine($"RegisterRecv Failed {e}");
            }
        }

        void OnRecvCompleted(object sender, SocketAsyncEventArgs args)
        {
            if (args.BytesTransferred > 0 && args.SocketError == SocketError.Success)
            {
                try
                {
                    // Write 커서 이동
                    if (_recvBuffer.OnWrite(args.BytesTransferred) == false)
                    {
                        disConnected_Action.Invoke(this);
                    }

                    // 컨텐츠 쪽으로 데이터를 넘겨주고 얼마나 처리했는지 받는다
                    int processLen = OnRecv(_recvBuffer.ReadSegment);
                    if (processLen < 0 || _recvBuffer.DataSize < processLen)
                    {
                        disConnected_Action.Invoke(this);
                    }

                    // Read 커서 이동
                    if (_recvBuffer.OnRead(processLen) == false)
                    {
                        disConnected_Action.Invoke(this);
                    }
                    RegisterRecv();
                }
                catch (Exception e)
                {
                    disConnected_Action.Invoke(this);
                }
            }
            else
            {
                disConnected_Action.Invoke(this);
            }
        }
    }
}
/*        public void OnConnected(EndPoint endPoint,Socket socket)
        {
            lock(_lock)
            { 
                _socket = socket;
                _disconnected = 0;
            }
            Console.WriteLine($"OnConnected : {endPoint}");
            RegisterRecv();
        }*/

/*        public bool CheckDisconnectedFucn()
        {
            if (Volatile.Read(ref _disconnected) == 1)
                return false;
            else
                return true;
        }*/