﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Numerics;
using System.Text;

namespace ServerCore
{
	public class Listener
	{
		Socket _listenSocket;
		Action<SocketAsyncEventArgs> _BrokerSocketCheck;
		
		public void Init(IPEndPoint endPoint,
			Action<SocketAsyncEventArgs> BrokerSessionCheck, int register = 1, int backlog = 1)
        {
            _listenSocket = new Socket(endPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            _BrokerSocketCheck += BrokerSessionCheck;

			_listenSocket.Bind(endPoint);
			_listenSocket.Listen(backlog);

            SocketAsyncEventArgs args = new SocketAsyncEventArgs();
            args.Completed += new EventHandler<SocketAsyncEventArgs>(OnAcceptCompleted);
            RegisterAccept(args);
        }

        void RegisterAccept(SocketAsyncEventArgs args)
		{
			args.AcceptSocket = null;

			bool pending = _listenSocket.AcceptAsync(args);
			if (pending == false)
				OnAcceptCompleted(null, args);
		}
		
		void OnAcceptCompleted(object sender, SocketAsyncEventArgs args)
		{
			if (args.SocketError == SocketError.Success)
				_BrokerSocketCheck.Invoke(args);
			else
				Console.WriteLine(args.SocketError.ToString());

			RegisterAccept(args);
		}
	}
}
