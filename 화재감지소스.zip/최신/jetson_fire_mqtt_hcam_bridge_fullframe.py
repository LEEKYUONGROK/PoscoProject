"""Jetson Orin Nano: USB CAMERA + D-Fire YOLO + MQTT + L293D + Arduino optical sensor (demo).

Requires: ultralytics, torch, opencv-python (Jetson-compatible), Flask,
          paho-mqtt, Jetson.GPIO, pyserial, v4l-utils.

IMPORTANT: Software vision/GPIO is NOT a certified industrial fire safety system.
MQTT is OPTIONAL: initial broker connection failure does not block Arduino/YOLO/motor/web.
A STOP(1) received before a disconnect remains latched until MQTT CLEAR(0) arrives.
"""
import os
os.environ["JETSON_MODEL_NAME"] = "JETSON_ORIN_NANO"

import re
import json
import secrets
import stat
import subprocess
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

import cv2
import torch
# MQTT는 부가 통신입니다. paho-mqtt 미설치/브로커 장애에도 로컬 장치 제어는 실행합니다.
try:
    import paho.mqtt.client as mqtt
    MQTT_IMPORT_ERROR = None
except ImportError as exc:
    mqtt = None
    MQTT_IMPORT_ERROR = str(exc)
import serial  # pip install pyserial
from flask import Flask, Response, jsonify, request
from ultralytics import YOLO

# =========================================================
# 1. 사용자 설정
# =========================================================
# MQTT는 선택적인 외부 통신 기능. 연결 실패 여부는 로컬 모터 운전에 영향 없음.
MQTT_ENABLED = True          # False면 브로커 접속을 시도하지 않음
MQTT_RETRY_SECONDS = 5.0    # MQTT 자체 초기화가 실패했을 때 재시도
BROKER_ADDRESS = "3.39.173.120"
PORT = 1883
SensorID = 301
Type = 5
TOPIC = "RealSensor/301"
RegistTOPIC = "factory/register"
MQTT_PERIOD = 3.0

# 외부 서버가 0/1 모터 정지 명령을 발행하는 Topic.
# 기본값은 Jetson 센서 Topic과 동일하지만, 송신한 자체 측정값은 명령으로 처리하지 않습니다.
# 서버의 실제 발행 토픽이 다르면 이 값만 변경하세요.
MQTT_COMMAND_TOPIC = "RealSensor/301"
# 1 = 외부 정지 요청, 0 = 외부 정지 요청 해제 (카메라 경보는 그대로 적용)
HAZARD_CLEAR_SECONDS = 2.0  # FIRE와 SMOKE가 모두 2초 연속 미검출이면 NORMAL + 모터 재가동

# 수신 서버와 사전에 합의해야 하는 감지값 (기존 333을 대체)
STATE_CODES = {
    "NORMAL": 0,
    "SMOKE": 1,
    "FIRE": 2,
    "STARTING": 3,
    "ERROR": -1,
}

MODEL_PATH = "/home/jetson/dfire_final_best_rtx2060s.pt"
# 라이터 불꽃 테스트라면 /home/jetson/best_lighter.pt 로 변경 가능.

TARGET_CAMERA_NAME = "Microsoft® LifeCam VX-2000: Mi"
TARGET_USB_PORT = "usb-3610000.usb-2.4"

IMG_SIZE = 416
CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480
JPEG_QUALITY = 75
FIRE_CONF = 0.20
SMOKE_CONF = 0.30
PREDICT_CONF = 0.10  # 각 클래스 임계값보다 반드시 낮게 설정

# 모터가 연결되어 있고 회전해도 안전한 상황에서만 True 사용
MOTOR_ENABLED = True
# 이전 요청대로 32/33을 교환하여 물리적으로 역방향 연속 회전
B_IA = 33                    # Jetson.GPIO BOARD 번호 (기존 32)
B_IB = 32                    # 기존 33
# 중간 정지 없이 한 방향으로 연속 회전합니다.
MOTOR_FREQUENCY = 100       # 소프트웨어 PWM, 정확한 100Hz는 보장되지 않음
FORWARD_DUTY = 100           # 연속 정방향 운전 PWM 듀티
START_TIME = 0.45            # 정지 상태에서 새로 시작할 때만 100% 기동 시간

# Arduino UNO R4 Minima: BTS1M-TDTD2의 NPN 출력(D3)을 USB 시리얼로 수신.
# Arduino는 STOP 또는 CLEAR를 100ms 간격으로 전송해야 합니다.
ARDUINO_REQUIRED = True      # True: USB/신호 이상 시에도 모터 운전 차단
ARDUINO_PORT = "/dev/ttyACM0" # 실제 Jetson 연결 포트에 맞게 수정
ARDUINO_BAUD = 115200
ARDUINO_TIMEOUT_SECONDS = 0.7 # 유효한 STOP/CLEAR 0.7초 미수신 시 즉시 정지
ARDUINO_STOP_DELAY_SECONDS = 0.3  # 첫 STOP 수신 후 0.5초 정지, 이후 CLEAR로 취소되지 않음
ARDUINO_RECONNECT_SECONDS = 1.0
# HCAM0 검사 완료와 같은 Jetson 내부에서만 연동 (HTTP 127.0.0.1:5000).
INSPECTION_KEY_FILE = Path.home() / ".config" / "jetson_inspection_bridge.key"
INSPECTION_PASS_TIMEOUT = 3.0  # 검사한 같은 너트가 광전센서를 계속 막으면 재정지

# =========================================================
# 2. 스레드 공유 상태
# =========================================================
app = Flask(__name__)
# 웹 조작 요청의 CSRF 방지용 세션별 토큰 (외부에 공개하지 않음)
WEB_CONTROL_TOKEN = secrets.token_urlsafe(32)
frame_condition = threading.Condition()
state_lock = threading.Lock()
shutdown_event = threading.Event()
alarm_event = threading.Event()       # 화재/연기/오류/MQTT/웹/Arduino 정지 OR 결합
vision_ready = threading.Event()      # 첫 정상 추론 전 모터 기동 방지
mqtt_wakeup = threading.Event()
mqtt_connected = threading.Event()
camera_done = threading.Event()
client = None  # MQTT 객체도 별도 스레드에서 초기화: 장애 시 다른 기능과 독립


def _inspection_key():
    """같은 Jetson 사용자만 읽을 수 있는 프로세스 간 공유 인증키."""
    INSPECTION_KEY_FILE.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        fd = os.open(str(INSPECTION_KEY_FILE), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        pass
    else:
        with os.fdopen(fd, "w", encoding="utf-8") as out:
            out.write(secrets.token_urlsafe(36) + "\n")
    mode = INSPECTION_KEY_FILE.stat().st_mode
    if mode & (stat.S_IRWXG | stat.S_IRWXO):
        raise RuntimeError(f"검사 인증키 파일 권한이 안전하지 않습니다 (chmod 600): {INSPECTION_KEY_FILE}")
    key = INSPECTION_KEY_FILE.read_text(encoding="utf-8").strip()
    if len(key) < 32:
        raise RuntimeError("검사 인증키 파일 내용이 손상되었습니다")
    return key


INSPECTION_KEY = _inspection_key()
INSPECTION_EPOCH = secrets.token_hex(10)

latest_jpeg = None
frame_number = 0
selected_camera = None
last_error = None
motor_error = None
live_state = "STARTING"
latched_alarm = None
report_state = "STARTING"
last_hazard_seen_at = None  # 마지막 FIRE/SMOKE 감지 시각 (monotonic)
# 실제로 MQTT 1을 수신한 경우에만 잠금. 브로커 미연결은 정지 사유가 아님.
# 안전을 위해 이미 수신한 1은 브로커가 끊겨도 유지 (재연결 후 0 수신 시 해제).
remote_stop_requested = False  # MQTT 명령 1로 정지, 0으로 이 요청만 해제
web_stop_requested = False     # 웹 수동 정지: 재개 버튼 전까지 유지
last_web_command_at = None
last_remote_command = None
last_remote_command_at = None

arduino_connected = False
arduino_state = "UNKNOWN"    # STOP / CLEAR / UNKNOWN
arduino_stop_requested = True
arduino_last_received = None  # monotonic timestamp for last valid input
arduino_last_command_at = None
arduino_error = None
arduino_stop_started_at = None  # 첫 STOP 수신 시각. CLEAR에도 유지, 수동 재설정 전까지 보존.
arduino_stop_latched = False  # 운전 전 STOP 또는 USB 통신 장애 중 STOP은 즉시 잠금
inspection_cycle_seq = 0
inspection_cycle_id = None        # STOP 한 번마다 부여되는 식별자
inspection_completed = None       # 최근 HCAM 완료 승인 기록
inspection_bypass_active = False  # 검사 완료한 같은 물체의 STOP은 CLEAR까지 무시
inspection_bypass_run_at = None
inspection_clear_count = 0
motor_active_event = threading.Event()  # 실제 모터 PWM 구동 상태

# 첫 센서 통신과 첫 정상 YOLO 추론이 완료될 때까지 운전을 허용하지 않음.
alarm_event.set()

# =========================================================
# 3. GPU 및 모델
# =========================================================
DEVICE = 0 if torch.cuda.is_available() else "cpu"
print(f"PyTorch: {torch.__version__} / CUDA: {torch.cuda.is_available()}")
if DEVICE != "cpu":
    print("GPU:", torch.cuda.get_device_name(0))

if not Path(MODEL_PATH).is_file():
    raise FileNotFoundError(f"YOLO 모델 파일이 없습니다: {MODEL_PATH}")

model = YOLO(MODEL_PATH)
print("YOLO 모델:", MODEL_PATH)
print("Classes:", model.names)


def _arduino_stop_due_locked(now=None):
    """최초 STOP을 기록한 뒤 설정된 지연이 지났거나 즉시 정지 래치가 설정되었는지."""
    if now is None:
        now = time.monotonic()
    return (arduino_stop_latched or
            (arduino_stop_started_at is not None and
             now - arduino_stop_started_at >= ARDUINO_STOP_DELAY_SECONDS))


def _arduino_block_reason_locked(now=None):
    """state_lock을 보유한 상태에서 호출. CLEAR 수신으로 예약/정지를 풀지 않음."""
    if not ARDUINO_REQUIRED:
        return None
    if not arduino_connected:
        return "Arduino USB 미연결"
    if arduino_last_received is None:
        return "Arduino 첫 감지 신호 대기"
    if now is None:
        now = time.monotonic()
    if now - arduino_last_received >= ARDUINO_TIMEOUT_SECONDS:
        return "Arduino 시리얼 신호 타임아웃"
    if inspection_bypass_active:
        if (inspection_bypass_run_at is not None and
                arduino_state == "STOP" and
                now - inspection_bypass_run_at >= INSPECTION_PASS_TIMEOUT):
            return "검사 후 광전센서 통과 제한시간 초과: 모터 정지"
        return None
    if _arduino_stop_due_locked(now):
        return "광전센서 STOP 기록: 모터 정지 유지 (센서 정지 해제 필요)"
    if arduino_stop_started_at is not None:
        # CLEAR가 도착해도 최초 STOP의 시각은 보존함.
        return None
    if arduino_stop_requested:
        return "광전센서 STOP (기동 전 감지): 모터 정지"
    return None


def _arduino_pending_locked(now=None):
    """첫 STOP 수신 후 설정된 지연이 아직 지나지 않았으면 True (CLEAR와 무관)."""
    if not ARDUINO_REQUIRED or arduino_stop_started_at is None:
        return False
    if now is None:
        now = time.monotonic()
    return not _arduino_stop_due_locked(now)


def _arduino_reset_allowed_locked(now=None):
    """정지 실행 완료 + 센서 CLEAR + USB 통신 정상일 때만 래치 해제 가능."""
    if not ARDUINO_REQUIRED or not arduino_connected or arduino_state != "CLEAR":
        return False
    if arduino_last_received is None:
        return False
    if now is None:
        now = time.monotonic()
    return (now - arduino_last_received < ARDUINO_TIMEOUT_SECONDS
            and _arduino_stop_due_locked(now)
            and not motor_active_event.is_set())


def reset_arduino_sensor_stop():
    """웹에서 명시적으로 광전센서 정지를 재설정. STOP/PENDING/통신 오류이면 거절."""
    global arduino_stop_started_at, arduino_stop_latched
    global inspection_bypass_active, inspection_bypass_run_at, inspection_clear_count
    with state_lock:
        now = time.monotonic()
        if not arduino_connected or arduino_last_received is None or (
                now - arduino_last_received >= ARDUINO_TIMEOUT_SECONDS):
            return False, "광전센서 USB 통신이 정상일 때만 해제할 수 있습니다."
        if arduino_state != "CLEAR":
            return False, "광전센서가 아직 STOP입니다. 물체를 제거해 주세요."
        if _arduino_pending_locked(now):
            return False, "최초 STOP 후 설정된 지연 정지가 완료되기 전에는 취소할 수 없습니다."
        if not _arduino_stop_due_locked(now):
            return False, "해제할 광전센서 정지 기록이 없습니다."
        if motor_active_event.is_set():
            return False, "아직 모터 정지 명령이 완료되지 않았습니다. 잠시 후 다시 시도하세요."
        arduino_stop_started_at = None
        arduino_stop_latched = False
        inspection_bypass_active = False
        inspection_bypass_run_at = None
        inspection_clear_count = 0
        _refresh_motor_lock_locked()
    print("[ARDUINO] 센서 STOP 기록 수동 해제 (현재 CLEAR)")
    return True, "광전센서 정지 기록을 해제했습니다. 다른 정지 조건이 없으면 재가동합니다."


def motor_stop_required():
    """PWM 중에도 시리얼 수신 시간초과를 직접 검사하여 정지 누락을 방지."""
    if alarm_event.is_set():
        return True
    with state_lock:
        if _arduino_block_reason_locked() is not None:
            alarm_event.set()
            return True
    return False


def _refresh_motor_lock_locked():
    """운전 허용은 로컬 센서/YOLO/웹/수신된 MQTT STOP이 모두 해제되어야 함.

    우선순위: 광전센서 STOP/통신 불량 및 화재/연기는 웹 운전 재개로 덮어쓸 수 없음.
    MQTT 브로커 *접속 자체*는 운전 조건에 포함하지 않음.
    """
    local_stop = report_state in ("FIRE", "SMOKE", "ERROR")
    if (local_stop or remote_stop_requested or web_stop_requested
            or _arduino_block_reason_locked() is not None):
        alarm_event.set()
    else:
        alarm_event.clear()


def change_state(detected):
    """YOLO 경보는 2초 무감지 시 해제. 원격 정지 요청은 독립적으로 유지.

    카메라/모터 ERROR는 자동 해제하지 않습니다.
    주의: 실제 화재 설비에서는 자동 모터 재가동 대신 수동 확인이 필요합니다.
    """
    global live_state, latched_alarm, report_state, last_hazard_seen_at
    now = time.monotonic()
    with state_lock:
        old_report = report_state
        old_locked = alarm_event.is_set()
        live_state = detected

        if detected == "ERROR" or latched_alarm == "ERROR":
            latched_alarm = "ERROR"
            report_state = "ERROR"
        elif detected in ("FIRE", "SMOKE"):
            # 불이나 연기가 감지될 때마다 정상 복귀 타이머를 리셋합니다.
            last_hazard_seen_at = now
            latched_alarm = detected
            report_state = detected
        elif detected == "NORMAL":
            vision_ready.set()
            if last_hazard_seen_at is None or now - last_hazard_seen_at >= HAZARD_CLEAR_SECONDS:
                last_hazard_seen_at = None
                latched_alarm = None
                report_state = "NORMAL"
            else:
                # FIRE/SMOKE 마지막 감지 이후 2초가 지나지 않음
                report_state = latched_alarm or "NORMAL"

        _refresh_motor_lock_locked()
        new_report = report_state
        new_locked = alarm_event.is_set()
        remote_stopped = remote_stop_requested

    if new_report != old_report or old_locked != new_locked:
        print(f"[감지] 현재={detected}, 로컬 MQTT={new_report}, "
              f"외부정지={remote_stopped}, 모터잠금={new_locked}")
        if new_report != old_report:
            mqtt_wakeup.set()


def set_remote_motor_stop(stop_requested: bool):
    """수신 1은 즉시 정지, 0은 원격 요청만 해제합니다.

    이 함수는 카메라 감지값/report_state를 절대 덮어쓰지 않습니다.
    """
    global remote_stop_requested, last_remote_command, last_remote_command_at
    with state_lock:
        old_locked = alarm_event.is_set()
        remote_stop_requested = bool(stop_requested)
        last_remote_command = int(stop_requested)
        last_remote_command_at = datetime.now().isoformat(timespec="seconds")
        _refresh_motor_lock_locked()
        local_status = report_state
        motor_locked = alarm_event.is_set()

    if stop_requested:
        print(f"[MQTT CMD] 1 수신: 외부 정지 요청 → 모터 정지 (로컬={local_status})")
    else:
        print(f"[MQTT CMD] 0 수신: 외부 정지 요청 해제 (로컬={local_status}, "
              f"모터잠금={motor_locked})")
    if old_locked != motor_locked:
        print(f"[MOTOR] 통합 정지 상태 변경: {'STOP' if motor_locked else 'READY'}")



def _motor_control_snapshot():
    """웹 UI와 API에 제공할 현재 모터 운전 허용/정지 사유."""
    with state_lock:
        local_state = report_state
        remote_stop = remote_stop_requested
        web_stop = web_stop_requested
        web_updated = last_web_command_at
        locked = alarm_event.is_set()
        arduino_block = _arduino_block_reason_locked()
        arduino_pending = _arduino_pending_locked()
        arduino_latched = _arduino_stop_due_locked()
        arduino_reset_available = _arduino_reset_allowed_locked()

    reasons = []
    if not MOTOR_ENABLED:
        reasons.append("모터 기능 비활성화")
    if shutdown_event.is_set():
        reasons.append("프로그램 종료 중")
    if camera_done.is_set():
        reasons.append("카메라/추론 중단")
    if not vision_ready.is_set():
        reasons.append("첫 정상 영상 분석 대기")
    if local_state in ("FIRE", "SMOKE", "ERROR"):
        reasons.append(f"감지 상태: {local_state}")
    if remote_stop:
        reasons.append("MQTT 외부 정지")
    if web_stop:
        reasons.append("웹 수동 정지")
    if arduino_block:
        reasons.append(arduino_block)
    if motor_error:
        reasons.append("모터 제어 오류")

    # 신호가 허용 상태라는 뜻이며 모터가 물리적으로 회전 중이라는 뜻은 아닙니다.
    allowed = not reasons and not locked
    return {
        "web_stop_requested": web_stop,
        "web_last_command_at": web_updated,
        "motor_run_allowed": allowed,
        "motor_stop_reasons": reasons,
        "motor_alarm_latched": locked,
        # 지연 중에도 웹 버튼으로 광전센서 STOP을 무시하거나 재개할 수 없음.
        "web_resume_available": web_stop and not arduino_pending and not [r for r in reasons if r != "웹 수동 정지"],
        "arduino_stop_pending": arduino_pending,
        "arduino_stop_latched": arduino_latched,
        "arduino_sensor_reset_available": arduino_reset_available,
    }


def set_web_motor_stop(stop_requested: bool):
    """웹 정지는 항상 허용. 재개는 모든 다른 정지 사유가 해제된 때만 허용.

    웹의 재개는 로컬 YOLO 및 MQTT 잠금을 해제하지 않습니다.
    다른 경보 중 눌린 재개는 거절하여 후일 의도치 않은 자동 재가동을 방지합니다.
    """
    global web_stop_requested, last_web_command_at
    with state_lock:
        if not stop_requested:
            blockers = []
            if not MOTOR_ENABLED:
                blockers.append("모터 기능 비활성화")
            if shutdown_event.is_set():
                blockers.append("프로그램 종료 중")
            if camera_done.is_set():
                blockers.append("카메라/추론 중단")
            if not vision_ready.is_set():
                blockers.append("영상 분석 준비 중")
            if report_state != "NORMAL":
                blockers.append(f"감지 상태 {report_state}")
            if remote_stop_requested:
                blockers.append("MQTT 외부 정지")
            arduino_block = _arduino_block_reason_locked()
            if arduino_block:
                blockers.append(arduino_block)
            if _arduino_pending_locked():
                blockers.append("광전센서 STOP: 지연 정지 대기 중")
            if motor_error:
                blockers.append("모터 제어 오류")
            if blockers:
                return False, "운전 재개 불가: " + ", ".join(blockers)

        web_stop_requested = bool(stop_requested)
        last_web_command_at = datetime.now().isoformat(timespec="seconds")
        _refresh_motor_lock_locked()

    print(f"[WEB MOTOR] {'수동 정지' if stop_requested else '재개 허용'}")
    return True, ("웹 수동 정지를 적용했습니다." if stop_requested
                  else "웹 수동 정지를 해제했습니다. 정상 운전 순서로 재개합니다.")


def parse_remote_stop_command(raw_payload: bytes | str, topic: str) -> int | None:
    """서버가 실제로 보낸 0/1 명령만 해석합니다.

    허용 예: 1, 0, 0|RealSensor/301|1, 304|3|RealSensor/301|0,
             {"motor_stop": 1}, {"fire_alarm": 1}, {"danger_signal": 0}
    우리의 자체 보고 payload(301|{"result": 0}|timestamp)는 무시합니다.
    사람 접근 코드 2도 원격 화재/정지 명령으로 해석하지 않습니다.
    """
    text = (raw_payload.decode("utf-8", errors="replace")
            if isinstance(raw_payload, bytes) else str(raw_payload)).strip()

    if text in ("0", "1"):
        return int(text)

    parts = [part.strip() for part in text.split("|")]
    if len(parts) == 3 and parts[1] == topic and parts[0] == "0" and parts[2] in ("0", "1"):
        return int(parts[2])
    if len(parts) == 4 and parts[2] == topic and parts[3] in ("0", "1"):
        return int(parts[3])

    if text.startswith("{"):
        try:
            obj = json.loads(text)
        except (json.JSONDecodeError, ValueError):
            return None
        if isinstance(obj, dict):
            for key in ("motor_stop", "fire_alarm", "danger_signal", "command"):
                value = obj.get(key)
                if value in (0, 1, "0", "1") and not isinstance(value, bool):
                    return int(value)
    return None



# =========================================================
# 3A. HCAM 검사 완료 수신: 같은 물체에 한 번만 재가동 허용
# =========================================================
def _inspection_state_locked():
    now = time.monotonic()
    return {
        "cycle_id": inspection_cycle_id,
        "sensor_state": arduino_state,
        "sensor_connected": arduino_connected,
        "sensor_fresh": (arduino_last_received is not None and
                         now - arduino_last_received < ARDUINO_TIMEOUT_SECONDS),
        "sensor_stopped": _arduino_stop_due_locked(now) and not motor_active_event.is_set(),
        "motor_active": motor_active_event.is_set(),
        "inspection_bypass": inspection_bypass_active,
        "last_completed": inspection_completed,
    }


def _apply_inspection_complete(cycle_id, record):
    """정상 저장된 현재 검사 건만 수용. 다른 정지 사유는 절대 해제하지 않음."""
    global arduino_stop_started_at, arduino_stop_latched
    global inspection_completed, inspection_bypass_active
    global inspection_bypass_run_at, inspection_clear_count
    if (not isinstance(record, dict) or
        record.get("frame_count") != 3 or
        record.get("capture_mode") not in ("auto", "manual") or
        record.get("predicted_label") not in ("OK", "NG") or
        not isinstance(record.get("object_id"), str) or
        not re.fullmatch(r"OBJ[0-9]{5,}", record["object_id"])):
        return False, "잘못된 검사 완료 데이터", 400
    with state_lock:
        if (inspection_completed is not None and
            inspection_completed["cycle_id"] == cycle_id and
            inspection_completed["object_id"] == record["object_id"]):
            return True, "이미 승인한 검사 완료 (중복 무시)", 200
        now = time.monotonic()
        if not cycle_id or cycle_id != inspection_cycle_id:
            return False, "광전센서 정지 회차가 일치하지 않습니다", 409
        if (not arduino_connected or arduino_last_received is None or
                now - arduino_last_received >= ARDUINO_TIMEOUT_SECONDS):
            return False, "Arduino 시리얼 상태가 정상이지 않습니다", 409
        if not _arduino_stop_due_locked(now) or motor_active_event.is_set():
            return False, "광전센서에 의해 모터가 완전히 정지된 뒤에만 재개할 수 있습니다", 409
        # STOP인 채로 물체를 이동시켜야 할 수 있음. 이번 한 물체에만 예외를 부여.
        inspection_bypass_active = arduino_state == "STOP"
        inspection_bypass_run_at = None
        inspection_clear_count = 0
        arduino_stop_started_at = None
        arduino_stop_latched = False
        inspection_completed = {
            "cycle_id": cycle_id,
            "object_id": record["object_id"],
            "predicted_label": record["predicted_label"],
            "capture_mode": record["capture_mode"],
            "completed_at": datetime.now().isoformat(timespec="seconds"),
        }
        _refresh_motor_lock_locked()  # FIRE/MQTT/WEB/카메라/통신 정지는 그대로 유지
    print(f"[HCAM] 검사 저장 완료: {record['object_id']} ({record['predicted_label']}); "
          f"광전센서 잠금만 해제 / bypass={inspection_bypass_active}", flush=True)
    return True, "검사 완료 승인. 다른 정지 조건이 없으면 모터 재가동", 200


@app.route("/inspection/pending", methods=["GET"])
@app.route("/inspection/complete", methods=["POST"])
def inspection_bridge():
    # Flask는 기존대로 127.0.0.1에만 바인딩. 파일 공유키까지 확인.
    token = request.headers.get("X-Inspection-Key", "")
    if not secrets.compare_digest(token, INSPECTION_KEY):
        return jsonify({"ok": False, "message": "검사 연동 인증 실패"}), 403
    if request.method == "GET":
        with state_lock:
            return jsonify({"ok": True, **_inspection_state_locked()})
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"ok": False, "message": "JSON 요청만 허용"}), 400
    ok, msg, code = _apply_inspection_complete(data.get("cycle_id"), data.get("record"))
    return jsonify({"ok": ok, "message": msg, "cycle_id": data.get("cycle_id")}), code


# =========================================================
# 4. MQTT 초기화/연결/보고
# =========================================================
def on_connect(client, userdata, flags, reason_code, properties=None):
    if reason_code != 0:
        mqtt_connected.clear()
        print(f"[MQTT] 연결 실패: {reason_code} (로컬 기능은 계속 동작)")
        return
    mqtt_connected.set()
    print(f"[MQTT] 연결 성공: {BROKER_ADDRESS}:{PORT}")
    try:
        sub_result, _ = client.subscribe(MQTT_COMMAND_TOPIC, qos=1)
        if sub_result == mqtt.MQTT_ERR_SUCCESS:
            print(f"[MQTT] 외부 모터 명령 구독: {MQTT_COMMAND_TOPIC}")
        else:
            print(f"[MQTT WARN] 명령 구독 실패: rc={sub_result}")
        # 연결 후 등록만 수행. 실패하더라도 Arduino/YOLO/웹/모터에는 영향 없음.
        info = client.publish(RegistTOPIC, f"{SensorID}|{Type}|{0}", qos=1)
        if info.rc == mqtt.MQTT_ERR_SUCCESS:
            print(f"[MQTT] 센서 등록 요청: {SensorID}|{Type}|{0}")
        else:
            print(f"[MQTT WARN] 등록 전송 실패: rc={info.rc}")
    except Exception as exc:
        print(f"[MQTT WARN] 연결 후 초기 설정 실패: {exc}")
    finally:
        mqtt_wakeup.set()  # 재연결 시에도 현재 상태 재전송


def on_disconnect(client, userdata, *args):
    mqtt_connected.clear()
    # 이미 수신한 MQTT STOP(1)은 안전상 유지. 단, 처음부터 브로커가 없었다면
    # remote_stop_requested=False 이므로 로컬 기능은 정상 실행.
    print("[MQTT] 연결 끊김 - 로컬 센서/YOLO/웹/모터 계속 실행, 재연결 대기")


def on_message(client, userdata, msg):
    try:
        payload = msg.payload.decode("utf-8", errors="replace")
        if msg.topic != MQTT_COMMAND_TOPIC:
            return
        command = parse_remote_stop_command(payload, msg.topic)
        if command is None:
            # 같은 Topic에 보낸 Jetson 자신의 3초 주기 보고는 명령이 아닙니다.
            if payload.startswith(f'{SensorID}|{{"result": '):
                return
            print(f"[MQTT 수신 무시] {msg.topic} : {payload[:160]}")
            return
        print(f"[MQTT 수신] {msg.topic} : {payload} -> motor_stop={command}")
        set_remote_motor_stop(command == 1)
    except Exception as exc:
        print("[MQTT] 메시지 처리 오류:", exc)


def mqtt_network_worker():
    """선택적 MQTT 연결 관리자. 네트워크 작업을 로컬 모터/웹 스레드와 분리."""
    global client
    if not MQTT_ENABLED:
        print("[MQTT] 사용 안 함 (MQTT_ENABLED=False); 로컬 제어는 정상 실행")
        return
    if mqtt is None:
        print(f"[MQTT] paho-mqtt 사용 불가: {MQTT_IMPORT_ERROR}; 로컬 제어는 정상 실행")
        return

    while not shutdown_event.is_set():
        local_client = None
        started = False
        try:
            try:
                local_client = mqtt.Client(
                    mqtt.CallbackAPIVersion.VERSION2,
                    client_id=f"JetsonFire-{SensorID}"
                )
            except AttributeError:
                local_client = mqtt.Client(client_id=f"JetsonFire-{SensorID}")
            local_client.on_connect = on_connect
            local_client.on_disconnect = on_disconnect
            local_client.on_message = on_message
            local_client.reconnect_delay_set(min_delay=1, max_delay=30)
            client = local_client
            # connect_async와 loop_start: 브로커 주소가 접속 불가여도 로컬 시작을 방해하지 않음.
            local_client.connect_async(BROKER_ADDRESS, PORT, keepalive=60)
            rc = local_client.loop_start()
            if rc != mqtt.MQTT_ERR_SUCCESS:
                raise RuntimeError(f"MQTT loop_start 실패: rc={rc}")
            started = True
            print("[MQTT] 별도 스레드에서 연결 시도 중 (실패해도 로컬 기능 계속 동작)")
            shutdown_event.wait()
        except Exception as exc:
            print(f"[MQTT] 네트워크 초기화 오류: {exc}; 로컬 제어 지속")
        finally:
            mqtt_connected.clear()
            if local_client is not None:
                if started:
                    try:
                        local_client.loop_stop()
                    except Exception as exc:
                        print(f"[MQTT] loop_stop 경고: {exc}")
                try:
                    local_client.disconnect()
                except Exception:
                    pass
            client = None
        if not shutdown_event.is_set():
            shutdown_event.wait(MQTT_RETRY_SECONDS)


def mqtt_sender_worker():
    """상태가 바뀔 때 및 3초마다 센서 데이터 송신 요청 (MQTT 장애 시 무시)."""
    last_offline_log_at = None
    while not shutdown_event.is_set():
        mqtt_wakeup.wait(timeout=MQTT_PERIOD)
        mqtt_wakeup.clear()
        if shutdown_event.is_set():
            break

        with state_lock:
            state = report_state
        value = STATE_CODES[state]
        dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message = f"{SensorID}|{{\"result\": {value}}}|{dt}"

        if not MQTT_ENABLED or mqtt is None:
            continue
        if not mqtt_connected.is_set() or client is None:
            # 3초마다 같은 미연결 메시지를 출력하지 않도록 제한
            now = time.monotonic()
            if last_offline_log_at is None or now - last_offline_log_at >= 30:
                print("[MQTT] 브로커 오프라인; 로컬 모터/Arduino/YOLO/웹 정상 동작")
                last_offline_log_at = now
            continue

        try:
            info = client.publish(TOPIC, message, qos=1, retain=False)
            if info.rc == mqtt.MQTT_ERR_SUCCESS:
                print(f"[MQTT 송신 요청] {TOPIC} : {message} ({state})")
            else:
                print(f"[MQTT WARN] 송신 실패: rc={info.rc}; 로컬 동작 영향 없음")
        except Exception as exc:
            print(f"[MQTT WARN] 송신 예외: {exc}; 로컬 동작 영향 없음")


# =========================================================
# 4A. Arduino UNO R4 USB 시리얼 광전센서 입력
# =========================================================
def arduino_serial_worker():
    """STOP 최초 수신 설정된 지연 후 정지. 이후 CLEAR는 예약/정지를 취소하지 않음.

    정지된 후에는 광전센서 CLEAR 상태에서 웹의 센서 정지 해제 버튼으로 복귀.
    케이블 분리 및 시리얼 타임아웃은 기다리지 않고 즉시 정지.
    """
    global arduino_connected, arduino_state, arduino_stop_requested
    global arduino_last_received, arduino_last_command_at, arduino_error
    global arduino_stop_started_at, arduino_stop_latched
    global inspection_cycle_seq, inspection_cycle_id
    global inspection_bypass_active, inspection_bypass_run_at, inspection_clear_count

    if not ARDUINO_REQUIRED:
        print("[ARDUINO] 비활성화: 광전센서 정지 조건 사용 안 함")
        return

    while not shutdown_event.is_set():
        ser = None
        try:
            # UNO R4 Minima는 보통 /dev/ttyACM0로 나타납니다.
            ser = serial.Serial(ARDUINO_PORT, ARDUINO_BAUD, timeout=0.15)
            with state_lock:
                arduino_connected = True
                arduino_state = "UNKNOWN"
                arduino_stop_requested = True
                arduino_last_received = None  # 재연결 직후 이전 CLEAR 신뢰 금지
                # USB 재연결은 이미 접수한 STOP 예약/정지 기록을 취소하지 않음.
                arduino_last_command_at = None
                arduino_error = None
                _refresh_motor_lock_locked()
            print(f"[ARDUINO] 연결됨: {ARDUINO_PORT} @ {ARDUINO_BAUD}")

            while not shutdown_event.is_set():
                payload = ser.readline()
                now = time.monotonic()
                if payload:
                    message = payload.decode("ascii", errors="ignore").strip().upper()
                    if message in ("STOP", "CLEAR"):
                        with state_lock:
                            old_state = arduino_state
                            old_reason = _arduino_block_reason_locked(now)
                            arduino_state = message
                            arduino_stop_requested = (message == "STOP")
                            if inspection_bypass_active:
                                # 검사 완료한 바로 그 물체만 통과시킴. 연속 3회 CLEAR 후 재무장.
                                if message == "CLEAR":
                                    inspection_clear_count += 1
                                    if inspection_clear_count >= 3:
                                        inspection_bypass_active = False
                                        inspection_bypass_run_at = None
                                        inspection_clear_count = 0
                                        print("[HCAM] 물체 통과 확인: 다음 광전센서 STOP 재무장", flush=True)
                                else:
                                    inspection_clear_count = 0
                                    if motor_active_event.is_set():
                                        if inspection_bypass_run_at is None:
                                            inspection_bypass_run_at = now
                                        elif now - inspection_bypass_run_at >= INSPECTION_PASS_TIMEOUT:
                                            # 같은 물체가 계속 광선을 막으면 정지. HCAM의 옛 완료 재사용 금지.
                                            inspection_bypass_active = False
                                            inspection_bypass_run_at = None
                                            arduino_stop_latched = True
                                            inspection_cycle_seq += 1
                                            inspection_cycle_id = f"{INSPECTION_EPOCH}:{inspection_cycle_seq}"
                                            print("[HCAM] 감지 유지 시간 초과: 재정지", flush=True)
                            elif (message == "STOP" and old_state != "STOP"
                                  and arduino_stop_started_at is None
                                  and not arduino_stop_latched):
                                inspection_cycle_seq += 1
                                inspection_cycle_id = f"{INSPECTION_EPOCH}:{inspection_cycle_seq}"
                                if motor_active_event.is_set():
                                    # 주행 중이면 STOP 최초 수신 시각에 단 한 번 예약.
                                    arduino_stop_started_at = now
                                else:
                                    # 아직 운전하지 않았다면 지연을 기다리지 않고 정지 유지.
                                    arduino_stop_latched = True
                            # CLEAR로 전환되어도 arduino_stop_started_at 및
                            # arduino_stop_latched는 절대 지우지 않는다.
                            arduino_last_received = now
                            arduino_last_command_at = datetime.now().isoformat(timespec="seconds")
                            _refresh_motor_lock_locked()
                            new_reason = _arduino_block_reason_locked(now)
                        if message != old_state or old_reason != new_reason:
                            if message == "STOP" and _arduino_pending_locked(now):
                                print(f"[ARDUINO] STOP 기록: 최초 감지에서 {ARDUINO_STOP_DELAY_SECONDS:.1f}초 뒤 반드시 정지")
                            elif message == "CLEAR" and _arduino_pending_locked(now):
                                print("[ARDUINO] CLEAR 수신, 기존 STOP 정지 예약은 유지")
                            else:
                                print(f"[ARDUINO] {message} / 모터정지={new_reason is not None}")
                    # 잡음, Arduino Serial.print 디버그 문구는 모터 재개 신호로 인정하지 않음.

                # 유효 메시지 수신이 중단되었을 때 timeout 정지 상태 갱신
                with state_lock:
                    old_locked = alarm_event.is_set()
                    _refresh_motor_lock_locked()
                    new_reason = _arduino_block_reason_locked()
                    new_locked = alarm_event.is_set()
                if new_locked and not old_locked and new_reason:
                    print(f"[ARDUINO] 통신 문제로 모터 정지: {new_reason}")

        except (serial.SerialException, OSError) as exc:
            with state_lock:
                arduino_error = str(exc)
            print(f"[ARDUINO] 연결/통신 오류: {exc}")
        except Exception as exc:
            with state_lock:
                arduino_error = str(exc)
            print(f"[ARDUINO] 예상치 못한 오류: {exc}")
            traceback.print_exc()
        finally:
            if ser is not None:
                try:
                    ser.close()
                except Exception:
                    pass
            with state_lock:
                # 통신 장애가 지연 정지 예약 도중 발생하면 즉시 정지하고 계속 잠금.
                if arduino_stop_started_at is not None or inspection_bypass_active:
                    arduino_stop_latched = True
                inspection_bypass_active = False
                inspection_bypass_run_at = None
                inspection_clear_count = 0
                arduino_connected = False
                arduino_state = "UNKNOWN"
                arduino_stop_requested = True
                arduino_last_received = None
                _refresh_motor_lock_locked()
        shutdown_event.wait(ARDUINO_RECONNECT_SECONDS)


# =========================================================
# 5. USB 카메라 자동 선택: 지정한 물리 USB 포트만 허용
# =========================================================
def find_target_camera_nodes():
    try:
        result = subprocess.run(
            ["v4l2-ctl", "--list-devices"],
            capture_output=True, text=True, check=True,
        )
    except FileNotFoundError as exc:
        raise RuntimeError("v4l2-ctl 설치 필요: sudo apt install v4l-utils") from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(f"카메라 목록 조회 실패: {exc.stderr}") from exc

    print("===== 카메라 목록 =====\n" + result.stdout)
    match_target = False
    nodes = []
    for line in result.stdout.splitlines():
        if not line.strip():
            continue
        if not line[0].isspace():
            match_target = (TARGET_CAMERA_NAME.lower() in line.lower()
                            and TARGET_USB_PORT in line)
        elif match_target:
            match = re.search(r"/dev/video\d+\b", line)
            if match:
                nodes.append(match.group(0))

    nodes = sorted(set(nodes), key=lambda path: int(path.replace("/dev/video", "")))
    if not nodes:
        raise RuntimeError(
            f"지정 USB 카메라 없음: {TARGET_CAMERA_NAME} ({TARGET_USB_PORT}). "
            "카메라 포트가 바뀌었는지 확인하세요."
        )
    return nodes


def open_target_camera():
    for device in find_target_camera_nodes():
        cap = cv2.VideoCapture(device, cv2.CAP_V4L2)
        if not cap.isOpened():
            cap.release()
            continue
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_WIDTH)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        for _ in range(10):
            ok, frame = cap.read()
            if ok and frame is not None and frame.size:
                print(f"[CAMERA] 선택: {device} ({frame.shape[1]}x{frame.shape[0]})")
                return cap, device
            time.sleep(0.1)
        cap.release()

    raise RuntimeError("대상 카메라에서 실제 영상을 받을 수 없습니다.")


# =========================================================
# 6. YOLO 화재·연기 검출 / 스트리밍
# =========================================================
def camera_worker():
    global latest_jpeg, frame_number, selected_camera, last_error
    cap = None
    try:
        cap, selected_camera = open_target_camera()
        prev = time.perf_counter()
        print("[YOLO] 화재·연기 검출 시작")

        while not shutdown_event.is_set():
            ok, frame = cap.read()
            if not ok or frame is None:
                raise RuntimeError("카메라 프레임 수신 실패")

            with torch.inference_mode():
                result = model.predict(
                    source=frame, imgsz=IMG_SIZE, conf=PREDICT_CONF,
                    device=DEVICE, verbose=False,
                )[0]
            if DEVICE != "cpu":
                torch.cuda.synchronize()

            # 웹 영상에는 카메라 원본 프레임 전체를 유지하고, 상태 텍스트만 하단 별도 영역에 표시합니다.
            annotated = cv2.copyMakeBorder(
                frame, 0, 192, 0, 0, cv2.BORDER_CONSTANT, value=(30, 30, 30)
            )
            boxes_to_draw = []
            fire_count = 0
            smoke_count = 0
            for box in result.boxes:
                cls_id = int(box.cls.item())
                score = float(box.conf.item())
                class_name = str(model.names[cls_id]).strip().lower()
                if class_name == "fire" and score >= FIRE_CONF:
                    fire_count += 1
                    color = (0, 0, 255)
                elif class_name == "smoke" and score >= SMOKE_CONF:
                    smoke_count += 1
                    color = (0, 165, 255)
                else:
                    continue
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                boxes_to_draw.append((x1, y1, x2, y2, class_name, score, color))

            if fire_count:
                detected = "FIRE"
                status_color = (0, 0, 255)
            elif smoke_count:
                detected = "SMOKE"
                status_color = (0, 165, 255)
            else:
                detected = "NORMAL"
                status_color = (0, 255, 0)

            # 상태와 모터 정지 신호를 JPEG 인코딩보다 먼저 갱신
            change_state(detected)

            now = time.perf_counter()
            fps = 1.0 / max(now - prev, 1e-6)
            prev = now

            info_y = frame.shape[0]
            cv2.putText(annotated, f"{detected} DETECTED" if detected != "NORMAL" else "NORMAL",
                        (15, info_y + 30), cv2.FONT_HERSHEY_SIMPLEX, .8, status_color, 2)
            cv2.putText(annotated, f"FPS: {fps:.1f}",
                        (15, info_y + 60), cv2.FONT_HERSHEY_SIMPLEX, .65, (255, 255, 255), 2)
            cv2.putText(annotated, f"Fire: {fire_count}  Smoke: {smoke_count}",
                        (15, info_y + 89), cv2.FONT_HERSHEY_SIMPLEX, .65, (255, 255, 255), 2)
            with state_lock:
                state_for_display = report_state
            cv2.putText(annotated, f"MQTT: {state_for_display} / Motor lock: {alarm_event.is_set()}",
                        (15, info_y + 118), cv2.FONT_HERSHEY_SIMPLEX, .53, (255, 255, 255), 2)

            for x1, y1, x2, y2, name, score, color in boxes_to_draw:
                cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
                cv2.putText(annotated, f"{name.upper()} {score:.2f}",
                            (x1, max(y1 - 10, 15)),
                            cv2.FONT_HERSHEY_SIMPLEX, .65, color, 2)
            with state_lock:
                remote_stopped = remote_stop_requested
            cv2.putText(annotated, f"Remote stop: {remote_stopped}",
                        (15, info_y + 147), cv2.FONT_HERSHEY_SIMPLEX, .6,
                        (0, 0, 255) if remote_stopped else (255, 255, 255), 2)
            cv2.putText(annotated, f"Camera: {selected_camera}",
                        (15, info_y + 175),
                        cv2.FONT_HERSHEY_SIMPLEX, .55, (255, 255, 0), 2)

            encoded, buffer = cv2.imencode(
                ".jpg", annotated, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY]
            )
            if encoded:
                with frame_condition:
                    latest_jpeg = buffer.tobytes()
                    frame_number += 1
                    frame_condition.notify_all()

    except Exception as exc:
        last_error = str(exc)
        print("[CAMERA/YOLO ERROR]", exc)
        traceback.print_exc()
        change_state("ERROR")
    finally:
        if cap is not None:
            cap.release()
        camera_done.set()
        with frame_condition:
            frame_condition.notify_all()
        print("[CAMERA] 종료")


# =========================================================
# 7. L293D 모터: 연속 운전 + 화재/연기/광전센서/웹/MQTT 정지
# =========================================================
def motor_stop(GPIO):
    GPIO.output(B_IA, GPIO.LOW)
    GPIO.output(B_IB, GPIO.LOW)


def interrupted_sleep(seconds):
    deadline = time.monotonic() + max(0, seconds)
    while time.monotonic() < deadline:
        if shutdown_event.is_set() or motor_stop_required() or camera_done.is_set():
            return False
        alarm_event.wait(min(0.01, deadline - time.monotonic()))
    return not (shutdown_event.is_set() or motor_stop_required() or camera_done.is_set())


def motor_run_continuous(GPIO):
    """정방향 연속 구동. 일정 시간이 지나도 멈추거나 역회전하지 않습니다.

    감지 STOP, 카메라/YOLO 오류, 웹 수동 정지, MQTT 정지, Arduino
    통신 단절, 프로그램 종료 시 PWM 루프를 종료하고 두 핀을 LOW로 만듭니다.
    소프트웨어 PWM 한 주기 안의 LOW 구간은 속도 제어를 위한 정상 동작입니다.
    """
    motor_stop(GPIO)
    if shutdown_event.is_set() or motor_stop_required() or camera_done.is_set():
        return False

    GPIO.output(B_IB, GPIO.LOW)
    try:
        # 재가동 시에만 기동 부스트 (정상 연속 회전 중 재적용 없음)
        GPIO.output(B_IA, GPIO.HIGH)
        motor_active_event.set()
        if not interrupted_sleep(START_TIME):
            return False

        period = 1.0 / MOTOR_FREQUENCY
        on_time = period * float(FORWARD_DUTY) / 100.0
        off_time = period - on_time

        while not shutdown_event.is_set() and not camera_done.is_set():
            if motor_stop_required():
                return False

            GPIO.output(B_IA, GPIO.HIGH)
            if not interrupted_sleep(on_time):
                return False

            GPIO.output(B_IA, GPIO.LOW)
            if not interrupted_sleep(off_time):
                return False
        return False
    finally:
        motor_stop(GPIO)
        motor_active_event.clear()


def motor_worker():
    global motor_error
    if not MOTOR_ENABLED:
        print("[MOTOR] 비활성화 (MOTOR_ENABLED=False)")
        return

    GPIO = None
    try:
        import Jetson.GPIO as GPIO
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(B_IA, GPIO.OUT, initial=GPIO.LOW)
        GPIO.setup(B_IB, GPIO.OUT, initial=GPIO.LOW)
        print("[MOTOR] GPIO 준비, 첫 정상 영상 분석까지 정지")

        # 정지 조건 발생 시 계속 정지 상태를 유지하고, 조건 해제 시 연속 운전 재개
        previously_locked = False
        while not shutdown_event.is_set():
            if (not vision_ready.is_set() or motor_stop_required()
                    or camera_done.is_set()):
                motor_stop(GPIO)
                if camera_done.is_set():
                    # 영상이 중단되면 자동 재시작하지 않음
                    alarm_event.set()
                if not previously_locked and vision_ready.is_set():
                    print("[MOTOR] 카메라/MQTT/웹/광전센서 정지 조건: 정지 및 복귀 대기")
                previously_locked = True
                shutdown_event.wait(0.05)
                continue

            if previously_locked:
                print("[MOTOR] 모든 정지 조건 해제: 정상 운전 재개")
                previously_locked = False

            print(f"[MOTOR] 연속 운전 - PWM {FORWARD_DUTY}% "
                  f"(시작 시만 100% {START_TIME}s)")
            motor_run_continuous(GPIO)
            # 정지 사유가 생기면 위 함수가 즉시 종료합니다.
            # 모든 잠금이 해제되면 다음 루프에서 다시 기동합니다.
    except Exception as exc:
        motor_error = str(exc)
        print("[MOTOR ERROR]", exc)
        traceback.print_exc()
        change_state("ERROR")
    finally:
        if GPIO is not None:
            try:
                motor_stop(GPIO)
                GPIO.cleanup()
            except Exception as exc:
                print("[MOTOR] GPIO cleanup 오류:", exc)
        print("[MOTOR] 완전 정지 명령 / 제어 종료")


# =========================================================
# 8. Flask 웹페이지 / 영상 / 상태 조회
# =========================================================
def generate_frames():
    last_num = -1
    while not shutdown_event.is_set():
        with frame_condition:
            frame_condition.wait_for(
                lambda: frame_number != last_num or camera_done.is_set()
                        or shutdown_event.is_set(),
                timeout=5,
            )
            if frame_number == last_num:
                if camera_done.is_set() or shutdown_event.is_set():
                    return
                continue
            payload = latest_jpeg
            last_num = frame_number
        if payload is None:
            continue
        yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + payload + b"\r\n"


@app.route("/")
def index():
    return """<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>D-Fire + MQTT + Motor Control</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  body { margin:0; background:#10151c; color:#edf2f8; font-family:Arial, sans-serif; }
  main { max-width:1020px; margin:auto; padding:18px 16px 35px; }
  h1 { font-size:clamp(20px, 3vw, 28px); margin:6px 0; }
  .desc { color:#adbccc; margin:9px 0 15px; }
  .video { display:block; width:100%; height:auto; max-width:960px; object-fit:contain; margin:auto; border-radius:12px; background:#19222b; border:1px solid #334254; }
  .panel { margin:14px auto; max-width:960px; padding:18px; background:#1b2530; border:1px solid #354758; border-radius:13px; }
  .panel-title { margin:0 0 13px; font-size:19px; }
  .status { font-size:16px; font-weight:700; margin-bottom:9px; }
  .status.stopped { color:#ff9d99; }
  .status.allowed { color:#90e1ad; }
  .reasons { color:#bbc8d6; font-size:14px; min-height:21px; line-height:1.5; }
  .buttons { display:flex; gap:12px; flex-wrap:wrap; margin-top:14px; }
  button { flex:1 1 240px; border:0; border-radius:10px; padding:17px 12px; font-size:19px; font-weight:700; cursor:pointer; color:white; }
  button:disabled { cursor:not-allowed; opacity:.40; }
  .stop { background:#bc3333; }
  .stop:not(:disabled):hover { background:#d14040; }
  .resume { background:#1e8653; }
  .resume:not(:disabled):hover { background:#269f63; }
  .feedback { min-height:23px; color:#eecf81; font-size:14px; margin-top:12px; }
  .note { color:#b8c7d5; font-size:13px; line-height:1.5; margin-top:12px; }
  a { color:#8cccff; }
</style>
</head>
<body><main>
  <h1>D-Fire YOLO + MQTT + Motor</h1>
  <p class="desc">Jetson Orin Nano | Fire/Smoke detection</p>
  <img class="video" src="/video_feed" alt="화재 감지 카메라 영상">
  <section class="panel" aria-label="모터 수동 제어">
    <h2 class="panel-title">모터 수동 제어</h2>
    <div id="motorState" class="status stopped" aria-live="polite">상태 확인 중...</div>
    <div id="motorReasons" class="reasons">서버 상태를 읽는 중입니다.</div>
    <div id="arduinoStatus" class="reasons">광전센서 연결 상태 확인 중...</div>
    <div id="mqttStatus" class="reasons">MQTT 연결 상태 확인 중...</div>
    <div class="buttons">
      <button class="stop" id="stopBtn" type="button">■ 모터 수동 정지</button>
      <button class="resume" id="resumeBtn" type="button" disabled>▶ 모터 운전 재개</button>
      <button class="resume" id="sensorResetBtn" type="button" disabled>↺ 광전센서 정지 해제</button>
    </div>
    <div id="feedback" class="feedback" role="status" aria-live="polite"></div>
    <p class="note">광전센서는 STOP 한 번으로 정지 예약을 기억합니다. 바로 CLEAR가 와도 최초 STOP의 설정된 지연 후 정지하며, 이후 CLEAR 상태에서 '광전센서 정지 해제'를 눌러야 다시 운전할 수 있습니다. 일반 '모터 운전 재개'는 센서 정지를 해제하지 않습니다. 이 웹 조작은 물리 비상정지 장치를 대신하지 않습니다.</p>
  </section>
  <p><a href="/status" target="_blank" rel="noopener">전체 상태(JSON) 보기</a></p>
</main>
<script>
(() => {
  const csrfToken = "__MOTOR_CONTROL_TOKEN__";
  const stopBtn = document.getElementById('stopBtn');
  const resumeBtn = document.getElementById('resumeBtn');
  const sensorResetBtn = document.getElementById('sensorResetBtn');
  const motorState = document.getElementById('motorState');
  const motorReasons = document.getElementById('motorReasons');
  const arduinoStatus = document.getElementById('arduinoStatus');
  const mqttStatus = document.getElementById('mqttStatus');
  const feedback = document.getElementById('feedback');
  let busy = false;

  async function refresh() {
    try {
      const response = await fetch('/status', {cache:'no-store'});
      if (!response.ok) throw Error('HTTP ' + response.status);
      const status = await response.json();
      const allowed = status.motor_run_allowed;
      motorState.textContent = allowed ? '운전 허용 (현재 모터 회전 여부는 별도)' : '정지 / 운전 차단';
      motorState.className = 'status ' + (allowed ? 'allowed' : 'stopped');
      motorReasons.textContent = status.motor_stop_reasons.length
        ? '정지 사유: ' + status.motor_stop_reasons.join(' · ')
        : '정지 사유 없음 · 감지 상태: ' + status.mqtt_report_state;
      arduinoStatus.textContent = '광전센서 Arduino: ' + status.arduino_sensor_state
        + (status.arduino_stop_pending ?
           ' / 정지까지 ' + status.arduino_stop_remaining_seconds + '초' : '')
        + (status.arduino_stop_latched ? ' / STOP 기록으로 정지 유지' : '')
        + ' / USB ' + (status.arduino_connected ? '연결' : '미연결')
        + (status.arduino_last_packet_age_seconds == null ? '' :
           ' / 마지막 신호 ' + status.arduino_last_packet_age_seconds + '초 전');
      mqttStatus.textContent = 'MQTT 브로커: ' + (status.mqtt_connected ? '연결됨' : '미연결')
        + ' / 로컬 제어 ' + (status.mqtt_offline_local_control ? '독립 동작' : '설정 확인 필요')
        + (status.remote_stop_requested ? ' / 과거에 수신한 MQTT STOP 유지 중' : '');
      stopBtn.disabled = busy || status.web_stop_requested;
      resumeBtn.disabled = busy || !status.web_resume_available;
      sensorResetBtn.disabled = busy || !status.arduino_sensor_reset_available;
    } catch (error) {
      motorState.textContent = '상태 확인 실패';
      motorState.className = 'status stopped';
      motorReasons.textContent = String(error);
      arduinoStatus.textContent = '광전센서 상태 확인 불가';
      mqttStatus.textContent = 'MQTT 상태 확인 불가';
      resumeBtn.disabled = true;
      sensorResetBtn.disabled = true;
      stopBtn.disabled = busy;
    }
  }

  async function command(action) {
    if (busy) return;
    busy = true;
    stopBtn.disabled = true;
    resumeBtn.disabled = true;
    sensorResetBtn.disabled = true;
    feedback.textContent = '요청을 보내는 중...';
    try {
      const response = await fetch('/motor/' + action, {
        method:'POST', cache:'no-store',
        headers: {'X-Control-Token': csrfToken}
      });
      const payload = await response.json();
      feedback.textContent = payload.message || '응답 확인 실패';
    } catch (error) {
      feedback.textContent = '명령 전송 실패: ' + String(error);
    } finally {
      busy = false;
      await refresh();
    }
  }
  stopBtn.addEventListener('click', () => command('stop'));
  resumeBtn.addEventListener('click', () => command('resume'));
  sensorResetBtn.addEventListener('click', () => command('sensor/reset'));
  refresh();
  setInterval(refresh, 1200);
})();
</script>
</body></html>""".replace("__MOTOR_CONTROL_TOKEN__", WEB_CONTROL_TOKEN)


@app.route("/video_feed")
def video_feed():
    return Response(
        generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame"
    )



@app.route("/motor/stop", methods=["POST"])
@app.route("/motor/resume", methods=["POST"])
def web_motor_command():
    # 웹 페이지 내에서 읽는 임의 토큰이 없는 외부 사이트의 요청은 거절 (CSRF 완화).
    token = request.headers.get("X-Control-Token", "")
    if not secrets.compare_digest(token, WEB_CONTROL_TOKEN):
        return jsonify({"ok": False, "message": "웹 제어 권한 확인 실패"}), 403

    stopping = request.path.endswith("/stop")
    ok, message = set_web_motor_stop(stopping)
    data = _motor_control_snapshot()
    return jsonify({"ok": ok, "message": message, **data}), (200 if ok else 409)

@app.route("/motor/sensor/reset", methods=["POST"])
def web_arduino_sensor_reset():
    token = request.headers.get("X-Control-Token", "")
    if not secrets.compare_digest(token, WEB_CONTROL_TOKEN):
        return jsonify({"ok": False, "message": "웹 제어 권한 확인 실패"}), 403
    ok, message = reset_arduino_sensor_stop()
    data = _motor_control_snapshot()
    return jsonify({"ok": ok, "message": message, **data}), (200 if ok else 409)


@app.route("/status")
def status():
    with state_lock:
        current = live_state
        published = report_state
        alarm = latched_alarm
        remote_stop = remote_stop_requested
        remote_value = last_remote_command
        remote_updated = last_remote_command_at
        sensor_state = arduino_state
        sensor_connected = arduino_connected
        sensor_last_received = arduino_last_received
        sensor_last_command = arduino_last_command_at
        sensor_error = arduino_error
        sensor_block = _arduino_block_reason_locked()
        sensor_pending = _arduino_pending_locked()
        sensor_latched = _arduino_stop_due_locked()
        sensor_reset_available = _arduino_reset_allowed_locked()
        sensor_remaining = (round(max(0, ARDUINO_STOP_DELAY_SECONDS -
                                (time.monotonic() - arduino_stop_started_at)), 2)
                            if sensor_pending else 0.0)
    return jsonify({
        **_motor_control_snapshot(),
        "camera_device": selected_camera,
        "frames_processed": frame_number,
        "camera_running": not camera_done.is_set() and selected_camera is not None,
        "live_detection": current,
        "mqtt_report_state": published,
        "mqtt_value": STATE_CODES[published],
        "mqtt_connected": mqtt_connected.is_set(),
        "mqtt_enabled": MQTT_ENABLED,
        "mqtt_offline_local_control": True,
        "motor_enabled": MOTOR_ENABLED,
        "motor_alarm_latched": alarm_event.is_set(),
        "remote_stop_requested": remote_stop,
        "remote_last_command": remote_value,
        "remote_last_command_at": remote_updated,
        "remote_command_topic": MQTT_COMMAND_TOPIC,
        "alarm_reason": alarm,
        "model": MODEL_PATH,
        "camera_error": last_error,
        "motor_error": motor_error,
        "arduino_enabled": ARDUINO_REQUIRED,
        "arduino_port": ARDUINO_PORT,
        "arduino_connected": sensor_connected,
        "arduino_sensor_state": sensor_state,
        "arduino_last_command_at": sensor_last_command,
        "arduino_last_packet_age_seconds": (
            round(max(0.0, time.monotonic() - sensor_last_received), 2)
            if sensor_last_received is not None else None
        ),
        "arduino_stop_reason": sensor_block,
        "arduino_stop_delay_seconds": ARDUINO_STOP_DELAY_SECONDS,
        "arduino_stop_pending": sensor_pending,
        "arduino_stop_latched": sensor_latched,
        "arduino_sensor_reset_available": sensor_reset_available,
        "arduino_stop_remaining_seconds": sensor_remaining,
        "arduino_error": sensor_error,
        "inspection_cycle_id": inspection_cycle_id,
        "inspection_last_completed": inspection_completed,
        "inspection_bypass_active": inspection_bypass_active,
    })


# =========================================================
# 9. 실행/종료
# =========================================================
if __name__ == "__main__":
    print("[START] Broker:", BROKER_ADDRESS, PORT)
    print("[START] MQTT status topic:", TOPIC)
    print("[START] MQTT command topic:", MQTT_COMMAND_TOPIC)
    print("[START] Camera port:", TARGET_USB_PORT)
    print("[START] Motor:", MOTOR_ENABLED)
    print(f"[START] Arduino optical sensor: enabled={ARDUINO_REQUIRED}, "
          f"port={ARDUINO_PORT}, baud={ARDUINO_BAUD}, timeout={ARDUINO_TIMEOUT_SECONDS}s, "
          f"stop delay={ARDUINO_STOP_DELAY_SECONDS}s")
    print(f"[START] Motor: continuous REVERSE (pins 33/32) {FORWARD_DUTY}% / "
          f"startup boost={START_TIME}s / PWM={MOTOR_FREQUENCY}Hz / "
          "sensor/fire/web/MQTT stop active")

    # 중요: MQTT 접속은 별도 스레드. 브로커 다운/접속 실패는 다른 기능의
    # 시작이나 운전 허용 여부에 영향을 주지 않습니다.
    threads = [
        threading.Thread(target=mqtt_network_worker, daemon=True, name="mqtt-network"),
        threading.Thread(target=mqtt_sender_worker, daemon=True, name="mqtt-sender"),
        threading.Thread(target=arduino_serial_worker, daemon=True, name="arduino-serial"),
        threading.Thread(target=camera_worker, daemon=True, name="camera-yolo"),
        threading.Thread(target=motor_worker, daemon=True, name="motor"),
    ]
    for thread in threads:
        thread.start()

    try:
        print("[WEB] http://127.0.0.1:5000 (VSCode SSH 포트 전달 이용)")
        app.run(host="127.0.0.1", port=5000,
                threaded=True, debug=False, use_reloader=False)
    finally:
        shutdown_event.set()
        alarm_event.set()
        mqtt_wakeup.set()
        with frame_condition:
            frame_condition.notify_all()
        for thread in threads:
            thread.join(timeout=3)
        # MQTT 정리도 mqtt_network_worker의 finally에서 수행함.
        print("[STOP] 종료 완료")
